<?php

$servername = "localhost";
$username = "vnxfuang_x";
$password = "vnxfuang_x";
$dbname = "vnxfuang_x";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>