<?php
// Improve database connection handling
include('conn.php');

// Add connection error handling
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// For Keys count
$sql = "SELECT COUNT(*) as id_keys FROM keys_code";
$result = mysqli_query($conn, $sql);
$keycount = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// For Active Keys count
$sql = "SELECT COUNT(devices) as devices FROM keys_code";
$result = mysqli_query($conn, $sql);
$active = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// For In-Active Keys Count
$sql = "SELECT COUNT(*) as devices FROM keys_code where devices IS NULL";
$result = mysqli_query($conn, $sql);
$inactive = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// For Users Count
$sql = "SELECT COUNT(*) as id_users FROM users";
$result = mysqli_query($conn, $sql);
$users = mysqli_fetch_assoc($result);
mysqli_free_result($result);

// Blocked key count
$sql = "SELECT COUNT(*) as id_keys FROM keys_code WHERE status = '0'";
$result = mysqli_query($conn, $sql);
$blockCount = mysqli_fetch_assoc($result)['id_keys'] ?? 0;
mysqli_free_result($result);

// Banned/block users
$sql = "SELECT COUNT(*) as id_users FROM users WHERE status = '2'";
$result = mysqli_query($conn, $sql);
$banusers = mysqli_fetch_assoc($result)['id_users'] ?? 0;
mysqli_free_result($result);

// Total Owner
$sql = "SELECT COUNT(*) as id_users FROM users WHERE level = '1'";
$result = mysqli_query($conn, $sql);
$ownerusers = mysqli_fetch_assoc($result)['id_users'] ?? 0;
mysqli_free_result($result);

// Total Admin
$sql = "SELECT COUNT(*) as id_users FROM users WHERE level = '2'";
$result = mysqli_query($conn, $sql);
$adminusers = mysqli_fetch_assoc($result)['id_users'] ?? 0;
mysqli_free_result($result);

// Total Reseller
$sql = "SELECT COUNT(*) as id_users FROM users WHERE level = '3'";
$result = mysqli_query($conn, $sql);
$resellerusers = mysqli_fetch_assoc($result)['id_users'] ?? 0;
mysqli_free_result($result);

$userid = session()->userid;
$sql = "SELECT `expiration_date` FROM `users` WHERE `id_users` = ?";
$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param($stmt, "s", $userid);
mysqli_stmt_execute($stmt);

mysqli_stmt_bind_result($stmt, $expiration_date);
mysqli_stmt_fetch($stmt);

$period = [
    'expiration_date' => $expiration_date
];

mysqli_stmt_close($stmt);

// Close the connection when done with all queries
mysqli_close($conn);

function HoursToDays($value)
{
    if($value == 1) {
       return "$value Hour";
    } else if($value >= 2 && $value < 24) {
       return "$value Hours";
    } else if($value == 24) {
       $darkespyt = $value/24;
       return "$darkespyt Day";
    } else if($value > 24) {
       $darkespyt = $value/24;
       return "$darkespyt Days";
    }
}

$dateTime = strtotime($period['expiration_date']);
$getDateTime = date("F d, Y H:i:s", $dateTime);
?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<style>
  /* ========= GLASSMORPHISM DASHBOARD THEME ========= */
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap');

  :root{
    --glass-bg: rgba(255,255,255,.15);
    --glass-border: rgba(255,255,255,.30);
    --primary-color:#4facfe;
    --secondary-color:#00f2fe;
    --text-color:#ffffff;
  }

  body{
    background: linear-gradient(135deg,#667eea,#764ba2);
    color: var(--text-color);
    font-family: 'Poppins',sans-serif;
    min-height: 100dvh;
  }

  .dashboard-container { width: 94%; max-width: 1200px; margin: 16px auto; }

  .card{
    background: var(--glass-bg) !important;
    border: 1px solid var(--glass-border) !important;
    border-radius: 16px !important;
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    box-shadow: 0 8px 28px rgba(0,0,0,.28);
    overflow: hidden;
    transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
    margin-bottom: 26px; /* extra gap so cards don't touch */
    position: relative;
  }
  .card:hover{ transform: translateY(-2px); box-shadow: 0 10px 30px rgba(0,0,0,.35); border-color: rgba(255,255,255,.45) !important; }

  .card-header{
    background: linear-gradient(90deg, rgba(255,255,255,.08), rgba(255,255,255,.02)) !important;
    border-bottom: 1px solid var(--glass-border) !important;
    color: var(--text-color) !important;
    letter-spacing: .8px;
    padding: 12px 16px;
  }

  /* grid gutters to keep spacing */
  .row { row-gap: 18px; }

  /* KPI cards (simple, compact) */
  .stat-card{ text-align:center; padding: 16px; }
  .stat-icon{ font-size: 1.8rem; margin-bottom: 10px; color: var(--secondary-color); }
  .stat-value{
    font-size: 1.7rem; font-weight: 800; margin-bottom: 2px;
    background: linear-gradient(45deg,var(--primary-color),var(--secondary-color));
    -webkit-background-clip:text; -webkit-text-fill-color:transparent;
  }
  .stat-label{ font-size:.9rem; opacity:.92; letter-spacing:.4px; }

  /* List items / badges */
  .list-group-item{
    background: rgba(255,255,255,.08) !important;
    border: 1px solid var(--glass-border) !important;
    color: var(--text-color) !important;
    transition: background .2s, transform .2s, border-color .2s;
    margin-bottom: 6px; border-radius: 10px !important;
  }
  .list-group-item:hover{ background: rgba(255,255,255,.14) !important; transform: translateX(4px); border-color: rgba(255,255,255,.45) !important; }
  .badge{
    padding: 7px 12px; border-radius: 999px;
    background: rgba(255,255,255,.10) !important; border: 1px solid var(--glass-border) !important;
    font-weight: 600; font-size: .82rem; color: var(--text-color) !important;
  }

  /* Expiration timer — NORMAL font */
  #exp{ font-family: 'Poppins', sans-serif; text-align:center; color: var(--text-color); font-size: 1.6rem; font-weight:600; margin:0; }

  /* Chart */
  .chart-container{ position: relative; height: 260px; }
  @media (max-width: 768px){ .chart-container{ height: 240px; } }
</style>
<div class="dashboard-container">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
            <?php if (session()->has('msgStatus')) : ?>
                <div id="status-message" class="alert alert-<?= session('msgStatus')['type'] ?> alert-dismissible fade show" role="alert">
                    <?= session('msgStatus')['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        </div> 
         
         <!-- Expiration Card -->
        <div class="col-lg-8 animate-in" style="animation-delay: 0.5s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i> Expiration
                </div>
                <div class="card-body">
                    <p id="exp"></p>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards Row -->
        <div class="col-lg-12 mb-4">
            <div class="row mobile-row">
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.1s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-key-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $keycount['id_keys']; ?></div>
                            <div class="stat-label">Total Keys</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.2s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-unlock-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $active['devices']; ?></div>
                            <div class="stat-label">Used Keys</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.3s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-lock-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $inactive['devices']; ?></div>
                            <div class="stat-label">Unused Keys</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.4s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $users['id_users']; ?></div>
                            <div class="stat-label">Total Users</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Additional Stats Row -->
        <div class="col-lg-12 mb-4">
            <div class="row mobile-row">
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.5s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-slash-circle-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $blockCount; ?></div>
                            <div class="stat-label">Blocked Keys</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.6s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-person-x-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $banusers; ?></div>
                            <div class="stat-label">Banned Users</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.7s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-person-badge-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $ownerusers; ?></div>
                            <div class="stat-label">Owners</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mobile-col animate-in" style="animation-delay: 0.8s">
                    <div class="card">
                        <div class="card-body stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-person-check-fill"></i>
                            </div>
                            <div class="stat-value"><?php echo $adminusers; ?></div>
                            <div class="stat-label">Admins</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- User Info Card -->
        <div class="col-lg-4 animate-in" style="animation-delay: 0.9s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-person-badge me-2"></i> Information
                </div>
                <div class="card-body">
                    <ul class="list-group list-hover mb-3">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-person-fill me-2"></i> Role</span>
                            <span class="badge">
                                <?= getLevel($user->level) ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-wallet-fill me-2"></i> Balance</span>
                            <span class="badge">
                                ₹<?= $user->saldo ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-clock-fill me-2"></i> Login Time</span>
                            <span class="badge">
                                <?= $time::parse(session()->time_since)->humanize() ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-box-arrow-right me-2"></i> Auto Log-out</span>
                            <span class="badge">
                                <?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Resellers Card -->
        <div class="col-lg-4 animate-in" style="animation-delay: 1.0s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-people-fill me-2"></i> Resellers
                </div>
                <div class="card-body">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="bi bi-person-lines-fill"></i>
                        </div>
                        <div class="stat-value"><?php echo $resellerusers; ?></div>
                        <div class="stat-label">Total Resellers</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Activity Chart -->
        <div class="col-lg-4 animate-in" style="animation-delay: 1.1s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-activity me-2"></i> Activity
                </div>
                <div class="card-body">
                    <div class="chart-container" style="position: relative; height: 240px;">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Required JS Libraries -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    // Expiration Timer
    var countDownTimer = new Date("<?php echo "$getDateTime"; ?>").getTime();
    // Update the count down every 1 second
    var interval = setInterval(function() {
        var current = new Date().getTime();
        // Find the difference between current and the count down date
        var diff = countDownTimer - current;
        // Countdown Time calculation for days, hours, minutes and seconds
        var days = Math.floor(diff / (1000 * 60 * 60 * 24));
        var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((diff % (1000 * 60)) / 1000);

        document.getElementById("exp").innerHTML = days + "d:" + hours + "h:" +
        minutes + "m:" + seconds + "s";
        // Display Expired, if the count down is over
        if (diff < 0) {
            clearInterval(interval);
            document.getElementById("exp").innerHTML = "EXPIRED";
        }
    }, 1000);
    
    // Animation for elements
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
        
        // Activity Chart (Doughnut)
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Used Keys', 'Unused Keys'],
                datasets: [{
                    data: [<?php echo $active['devices']; ?>, <?php echo $inactive['devices']; ?>],
                    backgroundColor: [
                        'rgba(74, 222, 128, 0.5)',
                        'rgba(248, 113, 113, 0.5)'
                    ],
                    borderColor: [
                        'rgba(74, 222, 128, 0.8)',
                        'rgba(248, 113, 113, 0.8)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white',
                            padding: 20
                        }
                    }
                },
                cutout: '70%'
            }
        });
    });
</script>
<?= $this->endSection() ?>