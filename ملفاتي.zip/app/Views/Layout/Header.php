<header>
  <nav class="navbar navbar-dark fixed-top glass-nav shadow-lg">
    <div class="container-fluid d-flex justify-content-between align-items-center">

      <!-- Brand -->
      <a class="navbar-brand brand-glass" href="<?= site_url() ?>">
        <!-- user-shield SVG icon (inline) -->
        <svg class="user-shield-icon" viewBox="1 1 22 22" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="img">
          <path d="M12 1L3 5V11C3 16.55 7.04 21.74 12 23C16.96 21.74 21 16.55 21 11V5L12 1ZM12 6C13.66 6 15 7.34 15 9C15 10.66 13.66 12 12 12C10.34 12 9 10.66 9 9C9 7.34 10.34 6 12 6ZM12 20C9.33 20 6.41 18.36 6.05 15C6.17 13 10 11.9 12 11.9C14 11.9 17.83 13 17.95 15C17.59 18.36 14.67 20 12 20Z"/>
        </svg>
        <?= BASE_NAME ?>
      </a>

      <!-- 3-line menu button -->
      <button
        class="menu-btn <?= isset($user) ? '' : 'disabled' ?>"
        onclick="<?= isset($user) ? 'toggleMenu(this)' : '' ?>"
        <?= isset($user) ? '' : 'disabled' ?>
        aria-label="Open menu"
        aria-controls="slideMenu"
        aria-expanded="false"
      >
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
      </button>

    </div>
  </nav>
</header>

<!-- Spacer under navbar -->
<div style="height: var(--nav-h);"></div>

<!-- Overlay -->
<div id="menuOverlay" class="menu-overlay" onclick="closeMenu()" aria-hidden="true"></div>

<!-- Slide-in Menu -->
<aside id="slideMenu" class="slide-menu" aria-hidden="true" role="dialog" aria-label="Sidebar menu">
  <div class="menu-header">
    <h5 class="m-0"></i><?= BASE_NAME ?>
  </div>

  <nav class="menu-links">
    <a href="<?= site_url('keys') ?>"><i class="bi bi-key-fill pe-2"></i>Keys</a>
    <a href="<?= site_url('keys/generate-random') ?>"><i class="bi bi-plus-circle-fill pe-2"></i>Rendom Key</a>
    <a href="<?= site_url('keys/generate') ?>"><i class="bi bi-plus-circle-fill pe-2"></i>Costom Key</a>
    <a href="<?= site_url('settings') ?>"><i class="bi bi-gear-fill pe-2"></i>Settings</a>
    <a href="<?= site_url('twofa') ?>" class="nav-link"><i class="fas fa-shield-alt"></i> 2AF Authentication</a>

    <?php if (isset($user)) : ?>
      
      <?php if ($user->level == 1): ?> 
        <!-- Level 1: OWNER gets all -->
        <div class="menu-divider"></div>
        <a href="<?= site_url('Server') ?>"><i class="bi bi-controller pe-2"></i>Online System</a>
        <a href="<?= site_url('lib') ?>"><i class="bi bi-person-plus-fill pe-2"></i>Online LIB</a>
        <a href="<?= site_url('ExtendDuration') ?>"><i class="bi bi-clock-history pe-2"></i>Extend Key</a>
        <a href="<?= site_url('balance') ?>"><i class="bi bi-cash-coin pe-2"></i>Add Balance</a>
        <a href="<?= site_url('price') ?>"><i class="bi bi-currency-exchange pe-2"></i>Add Duration</a>
        <a href="<?= site_url('settingsx') ?>"><i class="bi bi-pencil-fill pe-2"></i>Change Name</a>
        <a href="<?= site_url('license') ?>"><i class="bi bi-key-fill pe-2"></i>Change Licence</a>
        <a href="<?= site_url('account_approve') ?>"><i class="bi bi-person-check-fill pe-2"></i>Account Approvals</a>
        <a href="<?= site_url('admin/manage-users') ?>"><i class="bi bi-people-fill pe-2"></i>Manage Users</a>
        <a href="<?= site_url('admin/create-referral') ?>"><i class="bi bi-person-plus-fill pe-2"></i>Create Referral</a>
      
      <?php elseif ($user->level == 2): ?> 
        <!-- Level 2: ADMIN gets limited -->
        <div class="menu-divider"></div>
        <a href="<?= site_url('Server') ?>"><i class="bi bi-controller pe-2"></i>Online System</a>
        <a href="<?= site_url('lib') ?>"><i class="bi bi-person-plus-fill pe-2"></i>Online LIB</a>
        <a href="<?= site_url('account_approve') ?>"><i class="bi bi-person-check-fill pe-2"></i>Account Approvals</a>
        <a href="<?= site_url('admin/manage-users') ?>"><i class="bi bi-people-fill pe-2"></i>Manage Users</a>
        <a href="<?= site_url('admin/create-referral') ?>"><i class="bi bi-person-plus-fill pe-2"></i>Create Referral</a>
      <?php elseif ($user->level == 3): ?> 
        <!-- Level 3: Reseller gets only few -->
      
     
      <?php endif; ?>

    <?php endif; ?>

    <div class="menu-divider"></div>
    <a href="<?= site_url('logout') ?>" class="logout-link">
      <i class="bi bi-box-arrow-left pe-2"></i>Logout
    </a>
  </nav>

  <div class="menu-footer">
    <span class="chip">v<?= defined('APP_VERSION') ? APP_VERSION : '1.0' ?></span>
    <span class="chip">Secure</span>
  </div>
</aside>

<style>
  /* ===== FIRST THEME COLORS APPLIED ===== */
:root{
    --glass-bg: rgba(255,255,255,.14);
    --glass-border: rgba(255,255,255,.28);
    --brand1:#4facfe;   /* blue */
    --brand2:#00f2fe;   /* cyan */
    --ink:#0b1020;      /* deep background */
    --text:#fff;
    --muted:#e6fbff;
    --nav-h:60px;
  }

  /* NAVBAR */
  .glass-nav{
    z-index: 3000;
    background: linear-gradient(135deg, var(--neon-blue), var(--cyber-purple));
    border-bottom: 1px solid var(--glass-border);
    backdrop-filter: blur(12px);
  }
  .brand-glass{
    color: var(--neon-blue) !important; font-weight: 500;
    text-shadow: 0 0 12px rgba(0,242,255,.7);
    letter-spacing: .8px;
    display: inline-flex;
    align-items: center;
    gap:8px;
  }

  /* user-shield icon */
  .user-shield-icon{
    width:20px;
    height:20px;
    display:inline-block;
    vertical-align:middle;
    fill: currentColor; /* inherits color from .brand-glass */
    color: var(--neon-blue);
    filter: drop-shadow(0 0 8px rgba(0,242,255,.45));
  }

  /* MENU BUTTON */
  .menu-btn{ width: 32px; height: 24px; display:flex; flex-direction:column; justify-content:space-between;
             border:none; background:transparent; cursor:pointer; }
  .menu-btn .bar {
  height: 3px;
  width: 100%;
  background-color: rgba(0,242,255,.7); /* 👈 Yehi color apply hoga */
  border-radius: 4px;
  transition: .35s;
  box-shadow: 0 0 8px rgba(0,242,255,.7); /* matching neon glow */
}
  .menu-btn.active .bar:nth-child(1){ transform: rotate(45deg) translate(5px,5px); }
  .menu-btn.active .bar:nth-child(2){ opacity:0; }
  .menu-btn.active .bar:nth-child(3){ transform: rotate(-45deg) translate(6px,-6px); }

  .menu-btn.disabled{ opacity:.4; pointer-events:none; }

  /* OVERLAY */
  .menu-overlay{ position:fixed; top:var(--nav-h); left:0; width:100%; height:calc(100% - var(--nav-h));
    background:rgba(0,0,0,.5); z-index:2000; display:none; }
  .menu-overlay.show{ display:block; }

  /* SLIDE MENU */
  .slide-menu{
    position:fixed; top:var(--nav-h); right:0; width:0; height:calc(100% - var(--nav-h));
    background: var(--panel-bg); backdrop-filter: blur(14px);
    border-left:1px solid var(--glass-border); box-shadow:-8px 0 24px rgba(0,0,0,.5);
    overflow:hidden; transition: width .35s ease; z-index:2500;
    display:flex; flex-direction:column;
  }
  .slide-menu.open{ width: 240px; }

  .menu-header{
    padding:14px 16px; text-align:center;
    background: linear-gradient(135deg, rgba(0,242,255,.15), rgba(125,0,255,.25));
    color: var(--neon-blue); font-weight: 500;
    text-shadow: 0 0 10px rgba(0,242,255,.7);
    border-bottom:1px solid var(--glass-border);
  }

  .menu-links{ padding:6px 0; flex:1; overflow-y:auto; }
  .menu-links a{
    display:block; padding:12px 18px; color:#e0f7fa; font-weight:500;
    text-decoration:none; border-right:4px solid transparent;
    transform:translateX(24px); opacity:0;
    transition:all .3s ease;
  }
  .slide-menu.open .menu-links a{ transform:translateX(0); opacity:1; }
  .menu-links a:hover{
    background: rgba(0,242,255,.12); color:#fff;
    border-right:4px solid var(--neon-blue);
  }

  .menu-divider{ height:1px; background:rgba(255,255,255,.15); margin:10px 16px; }
 .logout-link {
  color: red !important;
}

  .menu-footer{ padding:10px 12px; border-top:1px solid rgba(255,255,255,.1); display:flex; gap:8px; }
  .chip{ padding:6px 10px; border-radius:999px; background:rgba(0,242,255,.1);
         border:1px solid var(--glass-border); font-size:12px; color:#fff; }
</style>

<script>
  (function(){
    const menu=document.getElementById('slideMenu');
    const overlay=document.getElementById('menuOverlay');
    const btn=document.querySelector('.menu-btn');

    window.toggleMenu=function(button){
      if(menu.classList.contains('open')){
        menu.classList.remove('open'); overlay.classList.remove('show');
        button.classList.remove('active'); button.setAttribute('aria-expanded','false');
      }else{
        menu.classList.add('open'); overlay.classList.add('show');
        button.classList.add('active'); button.setAttribute('aria-expanded','true');
      }
    }
    window.closeMenu=function(){
      menu.classList.remove('open'); overlay.classList.remove('show');
      btn?.classList.remove('active'); btn?.setAttribute('aria-expanded','false');
    }
    document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeMenu(); });
  })();
</script>