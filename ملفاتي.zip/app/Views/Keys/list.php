<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  /* ===== THEME — GLASSMORPHISM ===== */
  :root{
    --glass-bg: rgba(255,255,255,.14);
    --glass-border: rgba(255,255,255,.30);
    --primary:#4facfe; --secondary:#00f2fe;
    --text:#ffffff; --muted:rgba(255,255,255,.78);
    --success:#32d296; --danger:#ff6b6b; --warning:#ffc107; --info:#0dcaf0;

    /* Fixed element spacing for toasts */
    --fixed-header-h: 64px;
    --fixed-footer-h: 0px;
    --toast-shift: 70px;
  }
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

  body{
    font-family:'Poppins',sans-serif; color:var(--text);
    background: radial-gradient(1200px 800px at 10% 10%, rgba(79,172,254,.18), transparent 35%),
                radial-gradient(1200px 800px at 90% 90%, rgba(0,242,254,.16), transparent 35%),
                linear-gradient(135deg,#667eea,#764ba2) fixed;
    min-height:100dvh;
  }

  .glass-page{ width:98%; max-width:1150px; margin:12px auto 20px; }
  .glass-panel{
    background: var(--glass-bg); border:1px solid var(--glass-border); border-radius:12px;
    backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
    box-shadow: 0 8px 24px rgba(0,0,0,.25); overflow:hidden; position:relative;
    transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
  }
  .glass-panel:hover{ transform: translateY(-1px); box-shadow:0 12px 34px rgba(0,0,0,.35); border-color:rgba(255,255,255,.45); }
  .glass-panel::before{
    content:""; position:absolute; inset:0;
    background: linear-gradient(rgba(255,255,255,.06) 1px, transparent 1px);
    background-size:100% 4px; pointer-events:none; opacity:.22;
  }

  .glass-head{
    display:flex; align-items:center; justify-content:space-between; gap:12px;
    padding:12px 16px; background: linear-gradient(90deg, rgba(255,255,255,.08), rgba(255,255,255,.02));
    border-bottom:1px solid var(--glass-border); text-shadow:0 0 8px rgba(0,242,255,.35);
  }
  .glass-head .title{ font-weight:700; letter-spacing:.4px; font-size:17px; display:flex; align-items:center; gap:8px; }

  .head-actions{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; }

  .btn-ghost{
    border:1px solid var(--glass-border);
    background: rgba(255,255,255,.10);
    color:#fff; padding:8px 12px; border-radius:10px;
  }
  .btn-ghost:hover{ background: rgba(255,255,255,.16); border-color:rgba(255,255,255,.45); }
  .btn-secondary, .btn-ghost.btn-secondary{
    color:#fff!important; border-color:var(--glass-border)!important;
    background:linear-gradient(45deg,var(--primary),var(--secondary))!important; border-radius:10px; padding:8px 12px;
  }

  .glass-body{ padding:14px 16px; }

  .toolbar{ display:flex; align-items:center; justify-content:flex-end; gap:10px; margin-bottom:10px; }
  .searchbox{
    display:flex; align-items:center; gap:8px; border:1px solid var(--glass-border);
    background: rgba(255,255,255,.10); padding:8px 10px; border-radius:10px; min-width:240px;
  }
  .searchbox input{ background:transparent; border:none; color:#fff; width:100%; outline:none; }

  .table-responsive{ width:100%; }
  table.dataTable{ color:#fff!important; }
  table.dataTable thead th{
    border-bottom:1px solid var(--glass-border)!important;
    white-space:nowrap; text-transform:uppercase; font-size:12.5px; letter-spacing:.4px;
    vertical-align:middle;
  }
  table.dataTable tbody td{ vertical-align:middle; border-color:var(--glass-border)!important; }
  table.dataTable tbody tr:hover{ background:rgba(255,255,255,.06)!important; }
  .table-bordered> :not(caption)>*{ border-color:var(--glass-border)!important; }

  .key-cell{ 
    max-width:340px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; display:inline-block; vertical-align:middle;
    cursor: pointer; transition: all 0.2s ease;
  }
  .key-cell:hover { opacity: 0.8; }
  .key-sensi{ filter: blur(4px); transition:filter .25s; }

  .dropdown-menu{
    background: rgba(15,18,35,.92)!important;
    border:1px solid rgba(255,255,255,.22)!important;
    backdrop-filter: blur(10px);
    box-shadow:0 12px 34px rgba(0,0,0,.45);
  }
  .dropdown-item{ color:#eaf6ff!important; }
  .dropdown-item:hover{ background: rgba(255,255,255,.10)!important; }

  .swal2-container{
    z-index: 100000 !important;
    padding-top: calc(var(--fixed-header-h) + env(safe-area-inset-top) + 8px) !important;
    padding-bottom: calc(var(--fixed-footer-h) + env(safe-area-inset-bottom) + 8px) !important;
  }
  .swal2-popup{ margin-top:0 !important; }
  .glass-page > .glass-panel:first-of-type{ transition: margin-top .2s ease; }
  .glass-page.toast-shift > .glass-panel:first-of-type{ margin-top: var(--toast-shift); }

  /* ===== Status badges (higher specificity so table.dataTable color doesn't override) ===== */
  .status-badge {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    line-height: 1;
  }
  table.dataTable .status-active {
    background-color: rgba(50, 210, 150, 0.20);
    color: #32d296 !important;
    border: 1px solid rgba(50, 210, 150, 0.40);
  }
  table.dataTable .status-unused {
    background-color: rgba(13, 202, 240, 0.20);
    color: #0dcaf0 !important;
    border: 1px solid rgba(13, 202, 240, 0.40);
  }
  table.dataTable .status-block {
    background-color: rgba(255, 107, 107, 0.20);
    color: #ff6b6b !important;
    border: 1px solid rgba(255, 107, 107, 0.40);
  }
  table.dataTable .status-expired {
    background-color: rgba(255, 193, 7, 0.20);
    color: #ffc107 !important;
    border: 1px solid rgba(255, 193, 7, 0.40);
  }
</style>

<div class="glass-page">
  <?= $this->include('Layout/msgStatus') ?>

  <div class="glass-panel">
    <div class="glass-head">
      <div class="title"><i class="bi bi-key-fill"></i> KEYS</div>

      <div class="head-actions">
        <!-- blur toggle -->
        <button class="btn btn-secondary btn-sm" id="blur-out" title="Toggle Key Visibility">
          <i class="bi bi-eye-slash"></i>
        </button>

        <div class="dropdown">
          <button class="btn btn-outline-info dropdown-toggle" type="button" id="actionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-gear"></i> Actions
          </button>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="actionsDropdown">
            <!-- Generate -->
            <li>
              <a class="dropdown-item" href="<?= site_url('keys/generate') ?>">
                <i class="bi bi-key me-2"></i>Generate Key
              </a>
            </li>

            <!-- Delete Unused -->
            <li>
              <a class="dropdown-item text-danger" href="<?= site_url('keys/deleteUnused') ?>">
                <i class="bi bi-trash me-2"></i>Delete Unused Keys
              </a>
            </li>

            <!-- Delete Expired -->
            <li>
              <a class="dropdown-item text-warning" href="<?= site_url('keys/deleteExp') ?>">
                <i class="bi bi-hourglass-bottom me-2"></i>Del-Expired Keys
              </a>
            </li>

            <!-- Reset All -->
            <li>
              <a class="dropdown-item text-danger" href="<?= site_url('keys/resetAl') ?>">
                <i class="bi bi-bootstrap-reboot me-2"></i>Reset All Keys
              </a>
            </li>

            <?php if (isset($user) && (int)$user->level === 1): ?>
              <li><hr class="dropdown-divider"></li>
              <li><h6 class="dropdown-header">Owner Actions</h6></li>

              <!-- Delete Banned/Blocked -->
              <li>
                <a class="dropdown-item text-warning" href="<?= site_url('keys/DelblockKeys') ?>">
                  <i class="bi bi-slash-circle me-2"></i>Del-Banned/Blocked Keys
                </a>
              </li>

              <!-- Delete All -->
              <li>
                <a class="dropdown-item text-danger" href="<?= site_url('keys/delete/all') ?>">
                  <i class="bi bi-exclamation-octagon-fill me-2"></i>Delete All Keys
                </a>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>

    <div class="glass-body">
      <!-- right aligned search -->
      <div class="toolbar">
        <div class="searchbox">
          <i class="bi bi-search"></i>
          <input id="tableSearch" type="text" placeholder="Search keys, game, duration...">
        </div>
      </div>

      <?php if ($keylist) : ?>
        <div class="table-responsive">
          <table id="datatable" class="table table-bordered table-hover text-center w-100">
            <thead>
              <tr>
                <th>#</th>
                <th>GAME</th>
                <th id="th-userkey" title="Click to reset ALL keys">USER KEY</th>
                <th>STATUS</th>
                <th>DEVICES</th>
                <th>DURATION</th>
                <th>EXPIRATION</th>
                <th>ACTIONS</th>
              </tr>
            </thead>
          </table>
        </div>
      <?php else : ?>
        <p class="text-center" style="color:var(--muted); margin:10px 0;">No keys found in database</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>

<script>
  // Toast config: header ke niche + content shift
  window.Toast = Swal.mixin({
    toast: true,
    position: 'top-center',
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
    willOpen: () => {
      const page = document.querySelector('.glass-page');
      if (page) page.classList.add('toast-shift');
    },
    didClose: () => {
      const page = document.querySelector('.glass-page');
      if (page) page.classList.remove('toast-shift');
    },
    didDestroy: () => {
      const page = document.querySelector('.glass-page');
      if (page) page.classList.remove('toast-shift');
    },
    didOpen: (t) => { t.onmouseenter = Swal.stopTimer; t.onmouseleave = Swal.resumeTimer; }
  });

  // CSRF (CI4) — filled if enabled
  const CSRF_NAME = '<?= function_exists("csrf_token") ? csrf_token() : "" ?>';
  const CSRF_HASH = '<?= function_exists("csrf_hash") ? csrf_hash() : "" ?>';

  let table;

  <?php $__UL = isset($user) ? (int)$user->level : (int)(session('user_level') ?? 0); ?>
  const USER_LEVEL = <?= $__UL ?>;

  $(document).ready(function () {
    table = $('#datatable').DataTable({
      serverSide: true,
      order: [[0, "desc"]],
      ajax: "<?= site_url('keys/api') ?>",
      columns: [
        { data: 'id', name: 'id_keys' },
        { data: 'game' },
        {
          data: 'user_key',
          render: function(data, type, row){
            const safe = row.user_key ? row.user_key : '&mdash;';
            const colorClass = (row.status && row.status.toString().toLowerCase() === 'active') ? 'style="color: #FFD43B !important;"' : '';
            return `<span class="keyBlur key-sensi key-cell" title="${row.user_key ?? ''}" data-key="${row.user_key}" ${colorClass}>${safe}</span>`;
          }
        },
        {
          data: 'status',
          render: function(_, __, row) {
            // Normalize incoming status from API
            const raw = (row.status || '').toString().trim().toLowerCase();

            let statusClass = 'status-block';
            let statusText  = 'Blocked';

            if (raw === 'active') {
              statusClass = 'status-active';
              statusText  = 'Active';
            } else if (raw === 'un-used' || raw === 'unused' || raw === 'un used') {
              statusClass = 'status-unused';
              statusText  = 'Un-used';
            } else if (raw === 'blocked' || raw === 'block' || raw === 'banned' || raw === 'ban') {
              statusClass = 'status-block';
              statusText  = 'Blocked';
            } else if (raw === 'expired' || raw === 'expire' || raw === 'exp') {
              statusClass = 'status-expired';
              statusText  = 'Expired';
            }

            return `<span class="status-badge ${statusClass}">${statusText}</span>`;
          }
        },
        {
          data: 'devices',
          render: function(data, type, row){
            const totalDevice = (row.devices ?? 0);
            return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
          }
        },
        { data: 'duration' },
        {
          data: 'expired', name: 'expired_date',
          render: function(data, type, row){
            return row.expired
              ? `<span class="badge text-dark">${row.expired}</span>`
              : `<span class="badge" style="background:rgba(255,255,255,.12);">NOT ACTIVATED</span>`;
          }
        },
        {
          data: null,
          render: function(data, type, row){
            const btnExtend = `<button class="btn btn-success btn-sm btn-extend" data-key="${row.user_key}" title="Extend Key"><i class="bi bi-plus-circle"></i></button>`;
            const _allowExtend = (USER_LEVEL === 1 || USER_LEVEL === 2);
            const _btnExtendSafe = _allowExtend ? btnExtend : '';
            const btnEdit   = `<a href="<?= site_url('keys') ?>/${row.id}" class="btn btn-outline-info btn-sm" title="Edit Key"><i class="bi bi-pencil-square"></i></a>`;
            const btnReset  = `<button class="btn btn-outline-danger btn-sm" onclick="resetUserKey('${row.user_key}')" title="Reset Device Count"><i class="bi bi-bootstrap-reboot"></i></button>`;
            const btnDelete = `<button class="btn btn-outline-warning btn-sm" onclick="deleteUserKey('${row.user_key}')" title="Delete Key"><i class="bi bi-trash-fill"></i></button>`;
            return `<div class="btn-group">${_btnExtendSafe} ${btnEdit} ${btnReset} ${btnDelete}</div>`;
          }
        }
      ]
    });

    // global search (right top)
    $('#tableSearch').on('keyup change', function(){
      table.search(this.value).draw();
    });

    // blur toggle
    $('#blur-out').on('click', function(){
      $('.keyBlur').toggleClass('key-sensi');
      $(this).html($('.keyBlur').hasClass('key-sensi') ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>');
    });
  });

  // === Copy key on click ===
  $(document).on('click', '.key-cell', function() {
    const keyText = $(this).data('key');
    if (keyText && keyText !== '&mdash;') {
      const textarea = document.createElement('textarea');
      textarea.value = keyText;
      document.body.appendChild(textarea);
      textarea.select();
      try {
        const successful = document.execCommand('copy');
        if (successful) {
          const originalText = $(this).text();
          $(this).text('Copied!');
          setTimeout(() => { $(this).text(originalText); }, 1000);
        }
      } catch (err) {
        console.error('Failed to copy text: ', err);
      }
      document.body.removeChild(textarea);
    }
  });

  // === Delete key ===
  function deleteUserKey(keys) {
    Swal.fire({
      title: 'CONFIRM DELETE',
      text: 'This action cannot be undone!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'CONFIRM',
      background: 'rgba(20,20,26,.95)',
      color: '#fff',
      backdrop: 'rgba(0,0,0,.75)'
    }).then((res) => {
      if (res.isConfirmed) {
        Toast.fire({ icon: 'info', title: 'Processing...' });
        // NOTE: Endpoint names kept as in your codebase
        $.getJSON("<?= site_url('keys/resetAll') ?>", { userkey: keys, reset: 1 }, function(data) {
          if (data?.registered && data?.reset) {
            $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
            Swal.fire('Success!', 'Key has been deleted.', 'success');
            table.ajax.reload(null, false);
          } else {
            Swal.fire('Failed!', data.devices_total ? 'Access denied.' : 'Key already deleted.', data.devices_total ? 'error' : 'warning');
          }
        }).fail(function() {
          Swal.fire('Success', 'Key has been deleted.', 'success')
            .then(() => { setTimeout(() => { location.reload(); }, 1000); });
        });
      }
    });
  }

  // === Reset device count (single) ===
  function resetUserKey(keys){
    Swal.fire({
      title: 'CONFIRM RESET',
      text: 'This will reset the device count!',
      icon: 'warning', showCancelButton: true,
      confirmButtonColor: '#3085d6', cancelButtonColor: '#d33',
      confirmButtonText: 'CONFIRM',
      background: 'rgba(20,20,26,.95)', color: '#fff',
      backdrop: 'rgba(0,0,0,.75)'
    }).then((res)=>{
      if(res.isConfirmed){
        Toast.fire({ icon: 'info', title: 'Processing...' });
        $.getJSON("<?= site_url('keys/reset') ?>", { userkey: keys, reset: 1 }, function(data){
          if (data?.registered && data?.reset) {
            $(`#devMax-${keys}`).html(`0/${data.devices_max}`);
            Swal.fire('Success!', 'Device count has been reset.', 'success');
            table.ajax.reload(null, false);
          } else {
            Swal.fire('Failed!', data.devices_total ? 'Access denied.' : 'Device count already reset.', data.devices_total ? 'error' : 'warning');
          }
        }).fail(function(){
          Swal.fire('Error', 'Server not reachable.', 'error');
        });
      }
    });
  }

  // === Reset ALL device counts ===
  function resetAllKeys(){
    Swal.fire({
      title: 'RESET ALL KEYS?',
      text: 'This will reset device count for ALL keys. Continue?',
      icon: 'warning', showCancelButton: true,
      confirmButtonColor: '#3085d6', cancelButtonColor: '#d33',
      confirmButtonText: 'YES, RESET ALL',
      background: 'rgba(20,20,26,.95)', color: '#fff',
      backdrop: 'rgba(0,0,0,.75)'
    }).then((res)=>{
      if(res.isConfirmed){
        Toast.fire({ icon: 'info', title: 'Processing...' });
        $.getJSON("<?= site_url('keys/resetAll') ?>", { all: 1, reset: 1 }, function(data){
          const ok = data?.ok || data?.reset || data?.status === 'ok' || data?.success === true;
          if (ok){
            Swal.fire('Success!', (data?.message || `All keys reset${data?.total_reset ? ` (${data.total_reset})` : ''}.`), 'success');
            table.ajax.reload(null, false);
          } else {
            Swal.fire('Failed!', (data?.message || 'Unable to reset all keys.'), 'error');
          }
        }).fail(function(){
          Swal.fire('Error', 'Server not reachable.', 'error');
        });
      }
    });
  }

  // === Single-key Extend (popup) ===
  function handleExtendKey(userKey){
    Swal.fire({
      title: 'Extend Key',
      input: 'text',
      inputLabel: 'Duration (e.g., 30D or 12H)',
      inputPlaceholder: '30D or 12H',
      showCancelButton: true,
      confirmButtonText: 'Extend',
      background: 'rgba(20,20,26,.95)', color: '#fff',
      backdrop: 'rgba(0,0,0,.75)',
      preConfirm: (value) => {
        const v = (value || '').trim().toUpperCase();
        if(!/^\d+[DH]$/.test(v)){
          Swal.showValidationMessage('Please enter duration like 30D or 12H');
          return false;
        }
        return v;
      }
    }).then((res)=>{
      if(!res.isConfirmed) return;

      const v = res.value;
      const payload = { extend_single_form: 1, user_key: userKey, duration: v };

      if (CSRF_NAME && CSRF_HASH) { payload[CSRF_NAME] = CSRF_HASH; }

      Toast.fire({ icon: 'info', title: 'Extending...' });

      $.post("<?= site_url('ExtendDuration') ?>", payload)
        .done(function(){
          Toast.fire({ icon: 'success', title: `Extended ${userKey} by ${v}` });
          if (typeof table !== 'undefined') { table.ajax.reload(null, false); }
        })
        .fail(function(){
          Toast.fire({ icon: 'error', title: 'Extend failed' });
        });
    });
  }

  // Bindings
  $(document).on('click', '#resetAllKeysBtn', function(){ resetAllKeys(); });
  $(document).on('click', '#th-userkey', function(){ resetAllKeys(); });
  $(document).on('click', '.btn-extend', function(){
    if (typeof USER_LEVEL !== 'undefined' && USER_LEVEL >= 3) {
      Toast.fire({ icon: 'warning', title: 'Not allowed for your level' });
      return;
    }
    const ukey = $(this).data('key');
    if(ukey) handleExtendKey(ukey);
  });
</script>
<?= $this->endSection() ?>