#ifndef BETA_ESP_IMPORTANT_HACKS_H
#define BETA_ESP_IMPORTANT_HACKS_H

#include "socket.h"
#include "Color.h"
#include "items.h"
#include "rLogin/Login.h"
#include "Vector3.hpp"
#include <ctime> // Добавляем для clock()

bool isBehindWall(PlayerData player) {
    return player.isVisible == 0; // Используем правильное имя переменной
}


float Distance(Vec2 a, Vec2 b) {
    return sqrt(pow(b.x - a.x, 2) + pow(b.y - a.y, 2));
}

Color clrEnemy, clrEdge, clrBox, clrAlert, clr, clrTeam, clrDist,  clrHealth, clrText, grenadeColor;
float h, w, x, y, z, magic_number, mx, my, top, bottom, textsize, mScale, skelSize;
//Options options {1, -1, -1, -1,1, 1,200,300};
Options options{1, -1, -1, 3, false, false, 1, false, 200, 200, 200, 19, 19, -1, false};
OtherFeature otherFeature{false, false, false, false};

int botCount, playerCount;
Response response;
Request request;
char extra[30];
char text[100];
int hCounter = 50;

Color colorByDistance(int distance, int alpha) {
    Color clrDistance;
    if (distance < 600)
        clrDistance = Color::Yellow(255);

    if (distance < 300)
        clrDistance = Color::Orange(255);

    if (distance < 150)
        clrDistance = Color::Red(255);

    return clrDistance;
}

bool isOutsideSafeZone(Vec2 pos, Vec2 screen) {
    if (pos.y < 0) {
        return true;
    }
    if (pos.x > screen.x) {
        return true;
    }
    if (pos.y > screen.y) {
        return true;
    }
    return pos.x < 0;
}

std::string playerstatus(int GetEnemyState) {
    switch (GetEnemyState) {
        case 520:
        case 544:
        case 656:
        case 521:
        case 528:
        case 3145736:
            return "Aiming";
            break;
        default:
            return "";
            break;
    }
}

Vec2 calculatePosition(const Vec2 &center, float radius, float angleDegrees) {
    float angleRadians = angleDegrees * (M_PI / 180.0f); // Konversi derajat ke radian
    float x = center.x + radius * cos(angleRadians);
    float y = center.y + radius * sin(angleRadians);
    return Vec2(x, y);
}

bool colorPosCenter(float sWidth, float smMx, float sHeight, float posT, float eWidth, float emMx,
                    float eHeight, float posB)
{
    if (sWidth >= smMx && sHeight >= posT && eWidth <= emMx && eHeight <= posB)
    {
        return true;
    }
    return false;
}

Vec2 pushToScreenBorder(const Vec2 &location, const Vec2 &screen, float offset, float scale = 2.0f) {
    Vec2 center(screen.x / 2, screen.y / 2);
    float angle = atan2(location.y - center.y, location.x - center.x) * (180.0f / M_PI);
    return calculatePosition(center, offset * scale, angle);
}

// TODO Draw Radar
void DrawRadar(ESP canvas, Vec2 Location, Vec2 Pos, float Size, Color clr, int TeamID) {
    // LocalPos
    canvas.DrawFilledRoundRect(Color::White(255), {Pos.x - Size / 25, Pos.y - Size / 25}, {Pos.x + Size / 25, Pos.y + Size / 25});

    // EnemyPos
    canvas.DrawFillCircle(Color(clr.r, clr.g, clr.b, 255), Location, Size / 10, 0.5);

    if (isPlayerName) {
        // TeamID
        canvas.DrawText(Color::White(255), std::to_string(TeamID).c_str(), Location, Size / 10);
    }
}


void DrawESP(ESP esp, int screenWidth, int screenHeight) {




            if (memek) {

             esp.DrawTexture(Color::Green(255), OBFUSCATE("𝙰𝙽𝚃𝙸𝙱𝙰𝙽 ! 𝙾𝚗𝚕𝚒𝚗𝚎"), Vec2(screenWidth / 2, screenHeight / 7.5), screenHeight / 25);
          //   esp.DrawTextName(Color::Red(255), OBFUSCATE("   > >  Prime Cheat "), Vec2(screenWidth / 10, screenHeight / 13.5), screenHeight / 30);
                esp.DrawTexture(Color::Black(255), "𝐀𝐅𝐆𝐇", Vec2(screenWidth / 5.9, screenHeight / 10.5), screenHeight / 40);
                esp.DrawTexture(Color::Red(255), "𝐀𝐍𝐈𝐒", Vec2(screenWidth / 5.1, screenHeight / 10.5), screenHeight / 45);
                esp.DrawTexture(Color::Green(255), "𝐓𝐀𝐍", Vec2(screenWidth / 4.6, screenHeight / 10.5), screenHeight
                const char* aimText = "";
                if (options.aimBullet == 0) {
                    aimText = "BULLET TRACK";
                }else if (options.openState == 0) {
                    aimText = "AIMBOT PREDICTION";
                }else if (options.aimT == 0) {
                    aimText = "TOUCH PREDICTION";
                }else if ((otherFeature.LessRecoil || otherFeature.SmallCrosshair || otherFeature.WideView|| otherFeature.Aimbot)) {
                    aimText = "MEMORY HACK";
                }else{
                    aimText = "ESP ONLY";
                }


                esp.DrawTexture(Color::White(255), aimText, Vec2(screenWidth / 5, screenHeight / 1.09), screenHeight / 45);
                //esp.DrawTextMode2(Color::White(255), "", Vec2(screenWidth / 5, screenHeight / 1.13), screenHeight / 45);

                //esp.DrawTextBold(Color(255, 255, 255), credit.c_str(), Vec2(210, 80), 26);


                request.ScreenHeight = screenHeight;
                request.ScreenWidth = screenWidth;
                request.options = options;
                request.otherFeature = otherFeature;
                request.Mode = InitMode;

                botCount = 0, playerCount = 0;
                send((void *) &request, sizeof(request));
                receive((void *) &response);
                float mScaleY = screenHeight / (float) 1080;
                mScale = screenHeight / (float) 1080;
                mScale = screenHeight / (float) 1080;
                skelSize = (mScale * 1.5f);
                float BoxSize = (mScaleY * 2.0f);
                textsize = screenHeight / 50;
                Vec2 screen(screenWidth, screenHeight);



                if (response.Success) {

                    for (int i = 0; i < response.PlayerCount; i++) {

                        PlayerData Player = response.Players[i];
                        x = Player.HeadLocation.x;
                        y = Player.HeadLocation.y;

                        sprintf(extra, "%0.0fM", Player.Distance);
                        float magic_number = (response.Players[i].Distance * response.fov);
                        float namewidht = (screenWidth / 6) / magic_number;
                        float pp2 = namewidht / 2;
                        float mx = (screenWidth / 4) / magic_number;
                        float my = (screenWidth / 1.38) / magic_number;
                        float top = y - my + (screenWidth / 1.7) / magic_number;
                        float bottom = response.Players[i].Bone.lAn.y + my -
                                       (screenWidth / 1.7) / magic_number;
                        clrDist = colorByDistance((int) Player.Distance, 255);
                        clrAlert = _clrID((int) Player.TeamID, 80);
                        clrTeam = _clrID((int) Player.TeamID, 150);
                        clr = _clrID((int) Player.TeamID, 200);
                        Vec2 location(x,y);
                        float textsize = screenHeight / 50;

                        if (Player.isBot)
                        {
                            botCount++;
                            clrEnemy = Color::White(255);
                            clrEdge = Color::White(80);
                            clrBox = Color::White(255);
                            clrText = Color::Black(255);
                        }
                        else
                        {
                            playerCount++;
                            clrEnemy = clrDist;
                            clrEdge = clrAlert;
                            clrBox = Color::Red(255);
                            clrText = Color::White(255);
                        }

                        //    DrawRadar(esp, Player.RadarLocation, request.radarPos, request.radarSize, clr, Player.TeamID);


                        if (response.Players[i].HeadLocation.z != 1) {
                            // On Screen
                            if (x > -50 && x < screenWidth + 50) {

                                if (isSkeleton && Player.Bone.isBone) {
                                    float skelSize = (mScaleY * 2.0f);
                                    float headsize = (mScaleY * 7.0f);
                                    float distanceFromCamera = Player.Distance;
                                    float minHeadSize = (mScaleY * 2.0f);
                                    // float boxCenterX = (Player.Precise.x + Player.Precise.z) / 2;
                                    //          playerCount++;


//                                    if (!response.Players[i].isVisible) {
//                                        clr = Color::Red(255);
//                                        clrEdge = Color::Red(255);
//                                        esp.DrawText(Color().Red(255),"Cover", Vec2(x, top - 110),
//                                                 textsize);
//                                    } else {
//                                        clr = Color::Green(255);
//                                        clrEdge = Color::Green(255);
//                                        esp.DrawText(Color().Green(255),"Open", Vec2(x, top - 110),
//                                                 textsize);
//                                    }

                                    headsize = std::max(minHeadSize, headsize - std::min((distanceFromCamera - 10.0f) * 0.1f, 0.1f));
                                    esp.DrawFilledCircle(clrEdge, Player.Bone.head, static_cast<int>(headsize));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.neck.x,
                                                      response.Players[i].Bone.neck.y),
                                                 Vec2(response.Players[i].Bone.cheast.x,
                                                      response.Players[i].Bone.cheast.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.cheast.x,
                                                      response.Players[i].Bone.cheast.y),
                                                 Vec2(response.Players[i].Bone.pelvis.x,
                                                      response.Players[i].Bone.pelvis.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.neck.x,
                                                      response.Players[i].Bone.neck.y),
                                                 Vec2(response.Players[i].Bone.lSh.x,
                                                      response.Players[i].Bone.lSh.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.neck.x,
                                                      response.Players[i].Bone.neck.y),
                                                 Vec2(response.Players[i].Bone.rSh.x,
                                                      response.Players[i].Bone.rSh.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.lSh.x,
                                                      response.Players[i].Bone.lSh.y),
                                                 Vec2(response.Players[i].Bone.lElb.x,
                                                      response.Players[i].Bone.lElb.y));
                                    esp.DrawFilledCircle(clrEdge,
                                                         Vec2(response.Players[i].Bone.lWr.x,
                                                              response.Players[i].Bone.lWr.y),
                                                         screenHeight / 20 / magic_number);
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.rSh.x,
                                                      response.Players[i].Bone.rSh.y),
                                                 Vec2(response.Players[i].Bone.rElb.x,
                                                      response.Players[i].Bone.rElb.y));
                                    esp.DrawFilledCircle(clrEdge,
                                                         Vec2(response.Players[i].Bone.rWr.x,
                                                              response.Players[i].Bone.rWr.y),
                                                         screenHeight / 20 / magic_number);
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.lElb.x,
                                                      response.Players[i].Bone.lElb.y),
                                                 Vec2(response.Players[i].Bone.lWr.x,
                                                      response.Players[i].Bone.lWr.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.rElb.x,
                                                      response.Players[i].Bone.rElb.y),
                                                 Vec2(response.Players[i].Bone.rWr.x,
                                                      response.Players[i].Bone.rWr.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.pelvis.x,
                                                      response.Players[i].Bone.pelvis.y),
                                                 Vec2(response.Players[i].Bone.lTh.x,
                                                      response.Players[i].Bone.lTh.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.pelvis.x,
                                                      response.Players[i].Bone.pelvis.y),
                                                 Vec2(response.Players[i].Bone.rTh.x,
                                                      response.Players[i].Bone.rTh.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.lTh.x,
                                                      response.Players[i].Bone.lTh.y),
                                                 Vec2(response.Players[i].Bone.lKn.x,
                                                      response.Players[i].Bone.lKn.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.rTh.x,
                                                      response.Players[i].Bone.rTh.y),
                                                 Vec2(response.Players[i].Bone.rKn.x,
                                                      response.Players[i].Bone.rKn.y));
                                    esp.DrawFilledCircle(clrEdge,
                                                         Vec2(response.Players[i].Bone.lAn.x,
                                                              response.Players[i].Bone.lAn.y),
                                                         screenHeight / 20 / magic_number);
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.lKn.x,
                                                      response.Players[i].Bone.lKn.y),
                                                 Vec2(response.Players[i].Bone.lAn.x,
                                                      response.Players[i].Bone.lAn.y));
                                    esp.DrawLine(Color().White(255), skelSize,
                                                 Vec2(response.Players[i].Bone.rKn.x,
                                                      response.Players[i].Bone.rKn.y),
                                                 Vec2(response.Players[i].Bone.rAn.x,
                                                      response.Players[i].Bone.rAn.y));
                                    esp.DrawFilledCircle(clrEdge,
                                                         Vec2(response.Players[i].Bone.rAn.x,
                                                              response.Players[i].Bone.rAn.y),
                                                         screenHeight / 20 / magic_number);
                                }

                                // Player Box
                                if (isPlayerBox) {
                                    // 🟢 Настройка градиента цвета бокса (красный -> зеленый)
                                    Color clrStart(255, 0, 0, 225);    // Красный (0% HP)
                                    Color clrEnd(0, 255, 0, 225);      // Зеленый (100% HP)
                                    float healthPercent = response.Players[i].Health / 100.0f;
                                    Color clrBox = Color::Lerp(clrStart, clrEnd, healthPercent);

                                    // 🟢 Эффект появления бокса (анимация увеличения)
                                    static float animScale = 0.0f;
                                    float targetScale = 1.0f;
                                    animScale += (targetScale - animScale) * 0.1f; // Плавное увеличение

                                    float scaledWidth = namewidht * animScale;
                                    float scaledHeight = pp2 * animScale;

                                    // 🔥 Свечение вокруг бокса
                                    esp.DrawRect(Color(0, 0, 0, 100), BoxSize + 1, Vec2(x - scaledWidth - 2, top - 2), Vec2(x + scaledWidth + 2, bottom + 2));

                                    // 🔲 Верхняя часть бокса
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, top), Vec2(x - scaledWidth, top));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x - scaledWidth, top), Vec2(x - scaledWidth, top + scaledHeight));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, top), Vec2(x + scaledWidth, top + scaledHeight));

                                    // 🔲 Нижняя часть бокса
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, bottom), Vec2(x - scaledWidth, bottom));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x - scaledWidth, bottom), Vec2(x - scaledWidth, bottom - scaledHeight));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, bottom), Vec2(x + scaledWidth, bottom - scaledHeight));

                                    // 🔹 Декоративные уголки (делает ESP Box более стильным)
                                    float cornerSize = scaledWidth / 5;
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x - scaledWidth, top), Vec2(x - scaledWidth + cornerSize, top));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, top), Vec2(x + scaledWidth - cornerSize, top));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x - scaledWidth, bottom), Vec2(x - scaledWidth + cornerSize, bottom));
                                    esp.DrawLine(clrBox, BoxSize, Vec2(x + scaledWidth, bottom), Vec2(x + scaledWidth - cornerSize, bottom));
                                }

                                if (isPlayerLine) {
                                    // 🔹 Градиентный цвет линии (Красный -> Зеленый в зависимости от HP)
                                    Color clrStart(255, 0, 0, 225);  // Красный (0% HP)
                                    Color clrEnd(0, 255, 0, 225);    // Зеленый (100% HP)
                                    float healthPercent = response.Players[i].Health / 100.0f;
                                    Color clrLine = Color::Lerp(clrStart, clrEnd, healthPercent);

                                    // 🔹 Проверяем, находится ли враг за стеной
                                    if (isBehindWall(response.Players[i])) {
                                        clrLine = Color(0, 0, 255, 225); // 🔵 Синий цвет, если враг за стеной
                                    }

                                    // 🔥 Анимация появления линии (плавное удлинение)
                                    static float animLine = 0.0f;
                                    float targetLength = Distance(Vec2(x, top - screenHeight / 32), Vec2(screenWidth / 2, screenHeight / 10.5));
                                    animLine += (targetLength - animLine) * 0.1f; // Плавное увеличение

                                    // 🔥 Эффект свечения линии
                                    esp.DrawLine(Color(0, 0, 0, 100), screenHeight / 400, Vec2(screenWidth / 2, screenHeight / 10.5), Vec2(x, top - screenHeight / 32));

                                    // 🎨 Основная градиентная (или синяя) линия
                                    esp.DrawLine(clrLine, screenHeight / 500, Vec2(screenWidth / 2, screenHeight / 10.5), Vec2(x, top - screenHeight / 32));
                                }



                                //Player Health
                                  if (isPlayerHealth) {
                            float healthLength = screenWidth / 25;
                            if (healthLength < mx)
                                healthLength = mx;
                            if (response.Players[i].Health < 25)
                                clrHealth = Color(255, 0, 0, 145);
                            else if (response.Players[i].Health < 40)
                                clrHealth = Color(255, 165, 0, 145);
                            else if (response.Players[i].Health < 75)
                                clrHealth = Color(255, 255, 0, 145);
                            else
                                clrHealth = Color(38,221,129,150);
                            if (response.Players[i].Health == 0)
                                esp.DrawText(Color(255, 0, 0), OBFUSCATE("Knocked"),
                                             Vec2(x, top - screenHeight / 225), textsize);
                            else {
                                esp.DrawFilledRect(clrHealth,
                                                   Vec2(x - healthLength, top - screenHeight / 25),
                                                   Vec2(x - healthLength + (2 * healthLength) * response.Players[i].Health /100, top - screenHeight / 100));
                                esp.DrawRect(Color(0, 0, 0), screenHeight / 660,
                                             Vec2(x - healthLength, top - screenHeight / 25),
                                             Vec2(x + healthLength, top - screenHeight / 100));
                            }
                        }
                              /*  if (isPlayerHealth) {
                                    float healthLength = screenWidth / 24;
                                    float healthHeight = mScale * (screenHeight / 10); // Tinggi bar kesehatan
                                    float healthWidth = screenWidth / 200;  // Adjust the width of the health bar
                                    float healthX = response.Players[i].Bone.cheast.x + mx - (screenHeight / 50) / magic_number; // Adjust the X position to be to the right of the skeleton
                                    float distance = response.Players[i].Distance; // Assume distance is provided

                                    if (healthLength < mx)
                                        healthLength = mx;

                                    if (response.Players[i].Health < 25)
                                        clrHealth = Color(255, 0, 0, 185);
                                    else if (response.Players[i].Health < 50)
                                        clrHealth = Color(255, 204, 0, 185);
                                    else if (response.Players[i].Health < 75)
                                        clrHealth = Color(255, 255, 0, 185);
                                    else
                                        clrHealth = Color(34, 214, 97, 225);

                                    if (response.Players[i].Health == 0) {
                                        esp.DrawText(Color(255, 0, 0), "Knock",
                                                     Vec2(healthX, response.Players[i].Bone.cheast.y), textsize),
                                                screenHeight / 27;
                                    } else {
                                        esp.DrawFilledRect(Color(0, 0, 0, 130),
                                                           Vec2(x - screenWidth / 25, top - screenHeight / 18),
                                                           Vec2(x + screenWidth / 25, top - screenHeight / 33.5));
                                        esp.DrawFilledRect(clrHealth,
                                                           Vec2(x - screenWidth / 25, top - screenHeight / 33.5),
                                                           Vec2(x - screenWidth / 25 + (2 * screenWidth / 25) * response.Players[i].Health /100, top - screenHeight / 42));
                                    }

                                }*/





                                //Nation
                                if (isNation) {
                                    if (response.Players[i].Health <= 0) {
                                        //null
                                    } else {
                                        if (response.Players[i].isBot) {
                                            //nul
                                        } else {
                                            esp.DrawNation(Color().White(255),
                                                           response.Players[i].PlayerNation,
                                                           Vec2(response.Players[i].HeadLocation.x,
                                                                top - screenHeight / 65), textsize);
                                        }
                                    }
                                }
                                // UID

                                if (isPlayerUID) {
                                    if (response.Players[i].isBot) {
                                    } else {
                                        esp.DrawUserID(Color().White(255),
                                                       response.Players[i].PlayerUID,
                                                       Vec2(response.Players[i].HeadLocation.x - 40,
                                                            top - screenHeight / 16),
                                                       textsize);
                                    }}
                                //Player Head
                                if (isPlayerHead){
                                    esp.DrawFilledCircle(clrEdge,Vec2(response.Players[i].HeadLocation.x,response.Players[i].HeadLocation.y),screenHeight /12 /magic_number);
                                }

                                //Player Names
                                
                                  if (isPlayerName && response.Players[i].isBot) {
                                    sprintf(extra, "B O T");
                                    esp.DrawText(Color(255, 255, 255), extra,
                                                 Vec2(x, top - 18),
                                                 textsize);
                                } else if (isPlayerName) {
                                    esp.DrawName(Color().White(255),
                                                 response.Players[i].PlayerNameByte,
                                                 response.Players[i].TeamID,
                                                 Vec2(response.Players[i].HeadLocation.x,
                                                      top - 18),
                                                 textsize);
                                }

                                if (isPlayerDistance) {
                                    sprintf(extra, "%0.0f M", response.Players[i].Distance);
                                    esp.DrawText(Color(247, 175, 63,255), extra,
                                                 Vec2(x, bottom + screenHeight / 45),
                                                 textsize);
                                                
                                                 
                                }
                                
                              /*  if (isPlayerName) {
                                    esp.DrawFilledRect(clrTeam, Vec2(x - screenWidth / 29, top - screenHeight / 18), Vec2(x + screenWidth / 29, top - screenHeight / 33.5));
                                    if (Player.Health > 0) {
                                        if (Player.isBot) {
                                            esp.DrawOTH(Vec2(x - screenWidth / 100, top - screenHeight / 15));
                                        } else {
                                            esp.DrawPlayerName(Color::White(255),Player.PlayerNameByte, Vec2(x, top - screenHeight / 28), textsize);
                                        }
                                        esp.DrawFilledRect(clr, Vec2(x - screenWidth / 29, top - screenHeight / 18), Vec2(x - screenWidth / 48.5, top - screenHeight / 33.5));
                                        esp.DrawFilledRect(Color::Black(80), Vec2(x - screenWidth / 29, top - screenHeight / 18), Vec2(x - screenWidth / 48.5, top - screenHeight / 33.5));
                                        if(isTeamid) {
                                            esp.DrawTeamID(Color::White(255), Player.TeamID,
                                                           Vec2(x - screenWidth / 35.5,
                                                                top - screenHeight / 28),
                                                           screenHeight / 60);
                                        }
                                    } else if (Player.Health == 0) {
                                        esp.DrawText(Color::White(255), "KNOCK OUT", Vec2(x, top - screenHeight / 28), textsize);
                                    }
                                    esp.DrawText(Color::White(255), "▼", Vec2(x, top - screenHeight / 86), textsize);
                                }*/



                             /*   if (isPlayerDistance) {
                                    float distance = response.Players[i].Distance;

                                    // Цвет дистанции с градиентом (красный - ближе, зелёный - дальше)
                                    Color clrStart = Color(255, 0, 0, 255);    // Красный (близко)
                                    Color clrEnd = Color(0, 255, 0, 255);      // Зелёный (далеко)
                                    float distanceFactor = fmin(distance / 300.0f, 1.0f); // Ограничиваем до 300 метров
                                    Color distanceColor = Color::Lerp(clrStart, clrEnd, distanceFactor);

                                    // Анимация плавного появления текста
                                    static float scaleFactor = 0.5f;
                                    scaleFactor += (1.0f - scaleFactor) * 0.1f; // Плавное увеличение

                                    // Используем `clock()` вместо `GetTickCount()`
                                    float time = static_cast<float>(clock()) / CLOCKS_PER_SEC;
                                    float pulseEffect = (distance < 50) ? (0.9f + 0.1f * sin(time * 5.0f)) : 1.0f;

                                    sprintf(extra, "%.0f M", distance);
                                    esp.DrawText(distanceColor, extra, Vec2(x, bottom + screenHeight / 45),
                                                 textsize * scaleFactor * pulseEffect);
                                }*/



                                // weapon text only
                                if (isPlayerWeapon && response.Players[i].Weapon.isWeapon) {
                                    /*esp.DrawWeapon(Color(247, 175, 63), response.Players[i].Weapon.id,
                                                   response.Players[i].Weapon.ammo,response.Players[i].Weapon.ammo2,
                                                   Vec2(x, top - 65), 20.0f);*/
                                    esp.DrawWeapon(Color(247, 244, 200), response.Players[i].Weapon.id,  response.Players[i].Weapon.ammo,response.Players[i].Weapon.ammo,
                                                   Vec2(x, bottom + screenHeight / 23), textsize);
                                }


                                if (isPlayerWeaponIcon && response.Players[i].Weapon.isWeapon) {
                                    esp.DrawWeaponIcon(response.Players[i].Weapon.id,
                                                       Vec2(x - 45, top - 60));
                                }

                                //  if (Player.isVisible) {
                                if(playerstatus(Player.StatusPlayer) == "Aiming") {
                                    esp.DrawTexture(Color::Yellow(255), " ⚠\uFE0F Player Aiming at you ⚠\uFE0F", Vec2(screenWidth / 2, screenHeight / 4.3), screenHeight / 30);
                                }
                                // }



                            } //OnScreen

                            if (response.Players[i].HeadLocation.z == 1.0f)
                            {
                                if (!is360Alert)
                                    continue;

                                if (x > screenWidth - screenWidth / 12)
                                    x = screenWidth - screenWidth / 120;
                                else if (x < screenWidth / 120)
                                    x = screenWidth / 12;

                                if (y < screenHeight / 1)
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - x - 100, screenHeight - 48),
                                                 Vec2(screenWidth - x + 100, screenHeight + 2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(screenWidth - x - 100, screenHeight - 48),
                                                       Vec2(screenWidth - x + 100, screenHeight + 2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - x, screenHeight - 20),
                                                 textsize);
                                }
                                else
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - x - 100, 48),
                                                 Vec2(screenWidth - x + 100, -2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(screenWidth - x - 100, 48),
                                                       Vec2(screenWidth - x + 100, -2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - x, 25), textsize);
                                }
                            }
                            else if (x < -screenWidth / 10 || x > screenWidth + screenWidth / 10)
                            {
                                if (!is360Alert)
                                    continue;

                                if (y > screenHeight - screenHeight / 12)
                                    y = screenHeight - screenHeight / 120;
                                else if (y < screenHeight / 120)
                                    y = screenHeight / 12;

                                if (x > screenWidth / 2)
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - 88, y - 35),
                                                 Vec2(screenWidth + 2, y + 35));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(screenWidth - 88, y - 35),
                                                       Vec2(screenWidth + 2, y + 35));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - screenWidth / 80, y + 10),
                                                 textsize);
                                }
                                else
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(0 + 88, y - 35), Vec2(0 - 2, y + 35));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(0 + 88, y - 35), Vec2(0 - 2, y + 35));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth / 80, y + 10), textsize);
                                }
                            }
                            else if (y < -screenHeight / 10 || y > screenHeight + screenHeight / 10)
                            {
                                if (!is360Alert)
                                    continue;

                                if (x > screenWidth - screenWidth / 12)
                                    x = screenWidth - screenWidth / 120;
                                else if (x < screenWidth / 120)
                                    x = screenWidth / 12;

                                if (y > screenHeight / 2.5)
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(x - 100, screenHeight - 48), Vec2(x + 100,
                                                                                        screenHeight + 2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(x - 100, screenHeight - 48),
                                                       Vec2(x + 100, screenHeight + 2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(x, screenHeight - 20), textsize);
                                }
                                else
                                {
                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(x - 100, 48), Vec2(x + 100, -2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 140),
                                                       Vec2(x - 100, 48), Vec2(x + 100, -2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(x, 25), textsize);
                                }

                            }


                            /*if (is360Alert) {
                                const auto& points = Player.VPoints;
                                esp.DrawTriangle(clrEnemy, Vec2(points.at(0).x, points.at(0).y), Vec2(points.at(1).x, points.at(1).y), Vec2(points.at(2).x, points.at(2).y), 3.0f);
                                esp.DrawTriangleFilled(clrEnemy, Vec2(points.at(0).x, points.at(0).y), Vec2(points.at(1).x, points.at(1).y), Vec2(points.at(2).x, points.at(2).y));
                            }*/

                        } //Player.HeadLocation.z
                    } //response.PlayerCount

                    for (int i = 0; i < response.GrenadeCount; i++) {
                        GrenadeData grenade = response.Grenade[i];
                        if (!isGrenadeWarning || grenade.Location.z == 1.0f) {
                            continue;
                        }
                        const char *grenadeTypeText;
                        switch (grenade.type) {
                            case 1:
                                grenadeColor = Color::Red(255);
                                grenadeTypeText = "Grenade";
                                break;
                            case 2:
                                grenadeColor = Color::Orange(255);
                                grenadeTypeText = "Molotov";
                                break;
                            case 3:
                                grenadeColor = Color::Yellow(255);
                                grenadeTypeText = "Stun";
                                break;
                            default:
                                grenadeColor = Color::White(255);
                                grenadeTypeText = "Smoke";
                        }
                        sprintf(extra, "%s (%0.0f m)", grenadeTypeText, grenade.Distance);
                        esp.DrawText(grenadeColor, extra, Vec2(grenade.Location.x, grenade.Location.y + (screenHeight / 50)), textsize);
                        int WARNING = 4;

                        esp.DrawOTH2(Vec2(screenWidth / 2 - 160, 120), WARNING);
                        esp.DrawText(Color(255, 255, 255), OBFUSCATE("Warning : Throwable"),Vec2(screenWidth / 2 + 20, 145), 21);
                        esp.DrawText(grenadeColor, "〇", Vec2(grenade.Location.x, grenade.Location.y), textsize);
                    } //response.GrenadeCount


                    for (int i = 0; i < response.VehicleCount; i++) {
                        if (isVehicles) {
                            VehicleData vehicle = response.Vehicles[i];
                            if (vehicle.Location.z != 1.0f) {
                                esp.DrawVehicles(vehicle.VehicleName, vehicle.Distance, vehicle.Health, vehicle.Fuel, Vec2(vehicle.Location.x, vehicle.Location.y), screenHeight / 47);
                            }
                        }
                    } //response.VehicleCount

                    for (int i = 0; i < response.ItemsCount; i++) {
                        if (isItems) {
                            ItemData currentItem = response.Items[i];
                            if (currentItem.Location.z != 1.0f) {
                                esp.DrawItems(currentItem.ItemName, currentItem.Distance, Vec2(currentItem.Location.x, currentItem.Location.y), screenHeight / 50);
                            }
                        }
                    } //response.ItemsCount

                } //response.Success


                if (response.InLobby) {
   
    esp.DrawFilledRect(Color(166, 34, 31, 180), Vec2(screenWidth / 2 - 100, 30), Vec2(screenWidth / 2 + 100, 90));
    esp.DrawFilledRect(Color(255, 255, 255), Vec2(screenWidth / 2 - 100, 86), Vec2(screenWidth / 2 + 100, 90)); 
    esp.DrawText(Color(255, 255, 255), "LOBBY", Vec2(screenWidth / 2, 65), 32); 
} else {
    if (botCount + playerCount > 0) {
  
        esp.DrawFilledRect(Color(20, 20, 20, 180), Vec2(screenWidth / 2 - 250, 30), Vec2(screenWidth / 2 - 30, 90));
        esp.DrawFilledRect(Color(255, 0, 0), Vec2(screenWidth / 2 - 255, 30), Vec2(screenWidth / 2 - 250, 90)); 
        
        sprintf(extra, "BOTS: %d", botCount);
        esp.DrawText(Color(255, 70, 70), extra, Vec2(screenWidth / 2 - 140, 65), 28); 


        esp.DrawFilledRect(Color(20, 20, 20, 180), Vec2(screenWidth / 2 + 30, 30), Vec2(screenWidth / 2 + 250, 90));
        esp.DrawFilledRect(Color(255, 255, 255), Vec2(screenWidth / 2 + 250, 30), Vec2(screenWidth / 2 + 255, 90)); 
        
        sprintf(extra, "PLAYERS: %d", playerCount);
        esp.DrawText(Color(255, 255, 255), extra, Vec2(screenWidth / 2 + 140, 65), 28); 

    
        esp.DrawLine(Color(255, 255, 255, 120), 2.0f, Vec2(screenWidth / 2, 40), Vec2(screenWidth / 2, 80));
        
    } else {

        esp.DrawFilledRect(Color(46, 204, 113, 190), Vec2(screenWidth / 2 - 90, 30), Vec2(screenWidth / 2 + 90, 85));
        esp.DrawRect(Color(255, 255, 255, 220), 1.5f, Vec2(screenWidth / 2 - 90, 30), Vec2(screenWidth / 2 + 90, 85));
        
        esp.DrawText(Color(255, 255, 255), "S A F E", Vec2(screenWidth / 2, 62), 30); 
    }



                if (options.tracingStatus) {
                    float py = screenHeight / 2;
                    float px = screenWidth / 2;
                    esp.DrawFilledRect(Color::Green(50),
                                       Vec2(options.touchY - options.touchSize / 2,
                                            py * 2 - options.touchX + options.touchSize / 2),
                                       Vec2(options.touchY + options.touchSize / 2,
                                            py * 2 - options.touchX - options.touchSize / 2));
                }

                if (options.openState == 0 || options.aimBullet == 0 || options.aimT == 0) {
                    const Color textColor = (options.openState == 0) ? Color::Red(255) :(options.aimT == 0 ? Color::Blue(255) : Color::Green(255));
                    esp.DrawCircle(textColor, Vec2(screenWidth / 2, screenHeight / 2), options.aimingRange, 1.5);
                }

                if (isLootBox) {
                for (int i = 0; i < response.BoxItemsCount; i++) {
                    if (response.BoxItems[i].Location.z != 1.0f) {
                        BoxItemData *boxData = &response.BoxItems[i];
                        char *itemname;
                        int BoxCount = 0;
                        for (int ij = 0; ij < boxData->itemCount; ij++) {
                            if (GetBox((int) boxData->itemID[ij], &itemname)) {
                                BoxCount++;
                                esp.DrawDeadBoxItems(Color(), itemname, Vec2(boxData->Location.x, boxData->Location.y - (float) BoxCount * (screenHeight / 50)), textsize);
                            }
                        }
                    }
                }
                 }


    } //g_Token
} //OnDraw

#endif // BETA_ESP_IMPORTANT_HACKS_H
