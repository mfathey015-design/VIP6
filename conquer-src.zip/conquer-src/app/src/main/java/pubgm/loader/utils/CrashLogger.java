package pubgm.loader.utils;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CrashLogger implements Thread.UncaughtExceptionHandler {

    private final Context context;
    private final Thread.UncaughtExceptionHandler defaultHandler;

    public CrashLogger(Context context) {
        this.context = context;
        this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            File dir = new File(context.getExternalFilesDir(null), "CrashLogs");
            if (!dir.exists()) dir.mkdirs();

            String time = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            File logFile = new File(dir, "crash_" + time + ".txt");

            FileWriter writer = new FileWriter(logFile);
            writer.write("Thread: " + thread.getName() + "\n");
            writer.write("Error: " + throwable.toString() + "\n\n");

            for (StackTraceElement element : throwable.getStackTrace()) {
                writer.write(element.toString() + "\n");
            }
            writer.close();

            Log.e("CrashLogger", "Crash log saved: " + logFile.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Pass to system default handler after logging
        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, throwable);
        }
    }

    public static void init(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(new CrashLogger(context));
    }
}
