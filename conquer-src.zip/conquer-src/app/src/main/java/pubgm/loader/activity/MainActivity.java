package pubgm.loader.activity;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import androidx.viewpager2.widget.ViewPager2;
import net_62v.external.MetaActivationManager;
import net_62v.external.MetaApplicationInstaller;
import pubgm.loader.BoxApplication;
import android.graphics.drawable.ColorDrawable;
import pubgm.loader.floating.FightMode;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;

import static net_62v.external.MetaActivationManager.getActivationMessage;
import static pubgm.loader.activity.LoginActivity.USERKEY;
import static pubgm.loader.activity.LoginActivity.mahyong;

import pubgm.loader.utils.Internal;
import pubgm.loader.utils.UiKit;
import androidx.appcompat.app.AlertDialog;
import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import top.niunaijun.blackbox.utils.FileUtils;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import pubgm.loader.libhelper.FileHelper;
import android.widget.Toast;

import com.sdsmdg.tastytoast.TastyToast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;

import pubgm.loader.R;
import pubgm.loader.floating.FloatService;
import pubgm.loader.floating.Overlay;
import pubgm.loader.floating.ToggleAim;
import pubgm.loader.floating.ToggleBullet;
import pubgm.loader.floating.ToggleSimulation;
import pubgm.loader.libhelper.ApkEnv;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;
import android.os.Environment;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.topjohnwu.superuser.Shell;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaPackageManager;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.lsposed.lsparanoid.Obfuscate;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.os.AsyncTask;
import android.os.Environment;

import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.airbnb.lottie.LottieAnimationView;
//import static pubgm.loader.server.ApiServer.EXP;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
@Obfuscate
public class MainActivity extends ActivityCompat {
    private static final int REQUEST_PERMISSIONS = 1;
    public static String socket;
    public static String daemonPath;
    public static boolean check = false;
    public static int gameint = 1;
    //public static int bitversi = 64;
    public static boolean noroot = false;
    public static int device = 1;
    public static String game = "com.tencent.ig";
    public static int pushmode = 1;
    public static boolean Ischeck = false;
    public static String modeselect;
    public static String typelogin;
    static MainActivity instance;
    private ViewPager2 imageSlider;
    private Handler sliderHandler = new Handler(Looper.getMainLooper());
    private Runnable sliderRunnable;
    private static final long SLIDER_DELAY = 3000; // 3 seconds delay between slides
     private native String globalstatus();
    private MaterialButton startEspButton;
    private MaterialButton stopEspButton;
    private MaterialButton modePushOnButton;
    private MaterialButton modePushOffButton;
    
    Context ctx;
    InstallResult installResult;
    BlackBoxCore blackboxCore;

    private boolean isEspRunning = false;
    private boolean isModePushEnabled = false;
    private native String koreastatus();

    private native String tiwanstatus();

    private native String vngstatus();

    private native String bgmistatus();

    private com.google.android.material.navigation.NavigationView navigationView;

    static {
        try {
            System.loadLibrary("JungliCheatz");
        } catch (UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }
    public LinearProgressIndicator progres;
    public CardView enable, disable;
    public LinearLayout container;
    public static native String EXP();
    

    public static MainActivity get() {
        return instance;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.white));
            getWindow().setNavigationBarColor(getResources().getColor(R.color.white));
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
       initMenu1();
        initMenu2();
        
        blackboxCore = BlackBoxCore.get();
        blackboxCore.doCreate();
        
        devicecheck();
        if (!mahyong) {
            finish();
            finishActivity(1);
        }
        instance = this;
        isLogin = true;
        updateTextStates();
        updateButtonStates();
        initializeViews();
        Makedir();
    }
    private void initializeViews() {
        startEspButton = findViewById(R.id.StartEsp);
        stopEspButton = findViewById(R.id.StopEsp);
        modePushOnButton = findViewById(R.id.modesafeon);
        modePushOffButton = findViewById(R.id.modesafeoff);
        startEspButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPatcher();
                stopEspButton.setVisibility(View.VISIBLE);
                startEspButton.setVisibility(View.GONE);
            }
        });

        // ESP Stop Button
        stopEspButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPatcher();
                startEspButton.setVisibility(View.VISIBLE);
                stopEspButton.setVisibility(View.GONE);
            }
        });

        // Mode Push ON Button
        modePushOnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modePushOffButton.setVisibility(View.VISIBLE);
                modePushOnButton.setVisibility(View.GONE);
                pushmode = 1;
            }
        });

        // Mode Push OFF Button
        modePushOffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modePushOnButton.setVisibility(View.VISIBLE);
                modePushOffButton.setVisibility(View.GONE);
                pushmode = 0;
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        stopAutoSlider();
    }

    private void startAutoSlider() {
        sliderHandler.postDelayed(sliderRunnable, SLIDER_DELAY);
    }

    private void stopAutoSlider() {
        sliderHandler.removeCallbacks(sliderRunnable);
    }


    private void updateStatus(TextView textView, String rawStatus) {
        String statusValue = "Unknown";
        int color = Color.WHITE;  // Default color

        if (rawStatus == null) {
            Log.e("StatusUpdate", "rawStatus is null");
        } else if ("on".equalsIgnoreCase(rawStatus)) {
            statusValue = "Safe";
            color = Color.parseColor("#FFFFFF");  // White
        } else if ("off".equalsIgnoreCase(rawStatus)) {
            statusValue = "Unsafe";
            color = Color.parseColor("#F44336");  // Red
        } else {
            Log.e("StatusUpdate", "Unknown rawStatus value: " + rawStatus);
        }

        textView.setText(statusValue);
        textView.setTextColor(color);
    }



    private void updateTextStates() {
        TextView bgmiText = findViewById(R.id.bgmistatus);
        TextView globalText = findViewById(R.id.globalstatus);
        TextView koreaText = findViewById(R.id.koreastatus);
        TextView taiwanText = findViewById(R.id.tiwanstatus);
        TextView vngText = findViewById(R.id.vngstatus);

        updateStatus(bgmiText, bgmistatus());
        updateStatus(globalText, globalstatus());
        updateStatus(koreaText, koreastatus());
        updateStatus(taiwanText, tiwanstatus());
        updateStatus(vngText, vngstatus());
    }

    // Add this new method to check and update button states
    public void updateButtonStates() {
        // Get all the buttons
        MaterialButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
        MaterialButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
        MaterialButton InstallKRBtn = findViewById(R.id.InstallKR);
        MaterialButton InstallVNGBtn = findViewById(R.id.InstallVNG);
        MaterialButton InstallTWBtn = findViewById(R.id.InstallTW);

        updateButtonState(InstallBgmiBtn, "com.pubg.imobile", bgmistatus());
        updateButtonState(InstallGlobalBtn, "com.tencent.ig", globalstatus());
        updateButtonState(InstallKRBtn, "com.pubg.krmobile", koreastatus());
        updateButtonState(InstallVNGBtn, "com.vng.pubgmobile", vngstatus());
        updateButtonState(InstallTWBtn, "com.rekoo.pubgm", tiwanstatus());
    }

    private void updateButtonState(AppCompatButton button, String packageName, String status) {
        if ("off".equalsIgnoreCase(status)) {
            button.setEnabled(false);
            button.setText("Unsafe");
            button.setAlpha(0.5f); // Make button appear disabled
            return;
        }

        button.setEnabled(true);
        button.setAlpha(1.0f);

        
            if (isPackageInstalled(this, packageName)) {

                    button.setText("LAUNCH");
                }
             else {
                button.setText("INSTALL");
            
        } 
    }
    private void showPremiumDialog() {
        Dialog dialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_countdown);
        dialog.setCancelable(true);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        // Initialize countdown timer
        CountTimerAccout(dialog);

        // Setup OK button click handler
        MaterialButton okButton = dialog.findViewById(R.id.okButton);
        if (okButton != null) {
            okButton.setOnClickListener(v -> dialog.dismiss());
        }
        TextView keytxt = dialog.findViewById(R.id.keytxt);
        keytxt.setText(USERKEY);
        dialog.show();
    }
    private void CountTimerAccout(Dialog dialog) {
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                   String expiryDateStr = EXP(); // Assuming this gets the expiry date from your JSON

                    if (expiryDateStr != null && !expiryDateStr.isEmpty()) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        Date expiryDate = dateFormat.parse(expiryDateStr);
                        Date currentDate = new Date();

                        // Get reference to the countdown TextView
                        TextView countdownTextView = dialog.findViewById(R.id.countdownTextView);

                        if (expiryDate != null) {
                            // Calculate time difference
                            long diffInMillis = expiryDate.getTime() - currentDate.getTime();

                            if (diffInMillis > 0) {
                                // Convert to days, hours, minutes, seconds
                                long diffSeconds = diffInMillis / 1000 % 60;
                                long diffMinutes = diffInMillis / (60 * 1000) % 60;
                                long diffHours = diffInMillis / (60 * 60 * 1000) % 24;
                                long diffDays = diffInMillis / (24 * 60 * 60 * 1000);

                                // Format the values with leading zeros if needed
                                String daysStr = String.format(Locale.getDefault(), "%02d", diffDays);
                                String hoursStr = String.format(Locale.getDefault(), "%02d", diffHours);
                                String minutesStr = String.format(Locale.getDefault(), "%02d", diffMinutes);
                                String secondsStr = String.format(Locale.getDefault(), "%02d", diffSeconds);

                                // Update the TextView with formatted countdown
                                String countdownText = String.format("%sd %sh %sm %ss",
                                        daysStr, hoursStr, minutesStr, secondsStr);
                                countdownTextView.setText(countdownText);
                            } else {
                                // If expired, set to "00d 00h 00m 00s"
                                countdownTextView.setText("00d 00h 00m 00s");

                                // Optionally show an expiry message
                                Toast.makeText(getApplicationContext(), "Your subscription has expired", Toast.LENGTH_SHORT).show();
                            }

                            // Schedule the next update
                            handler.postDelayed(this, 1000);
                        } else {
                            // Invalid date
                            countdownTextView.setText("--d --h --m --s");
                        }
                    } else {
                        // No expiry date available
                        TextView countdownTextView = dialog.findViewById(R.id.countdownTextView);
                        countdownTextView.setText("--d --h --m --s");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    // Handle the exception gracefully
                    TextView countdownTextView = dialog.findViewById(R.id.countdownTextView);
                    countdownTextView.setText("--d --h --m --s");
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }

    public void devicecheck() {
        if (Shell.rootAccess()) {
            modeselect = "ROOT MODE " + "ANDROID " + Build.VERSION.RELEASE;
            Ischeck = true;
            noroot = true;
            device = 1;
        } else {
            modeselect = "PLAY SAFE" + "Kill" + Build.VERSION.RELEASE;
            Ischeck = true;
            device = 2;
        }
    }

    public boolean isPackageInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true; // Package is installed
        } catch (PackageManager.NameNotFoundException e) {
            return false; // Package is not installed
        }
    }


    @SuppressLint("SetTextI18n")
    public void initMenu1() {
        findViewById(R.id.premium_menu).setOnClickListener(v -> showPremiumDialog());
        LinearLayout layhome3 = findViewById(R.id.hackkkk);
        MaterialButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
        MaterialButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
        MaterialButton InstallKRBtn = findViewById(R.id.InstallKR);
        MaterialButton InstallVNGBtn = findViewById(R.id.InstallVNG);
        MaterialButton InstallTWBtn = findViewById(R.id.InstallTW);


        if (Shell.rootAccess()) {
            InstallBgmiBtn.setText("START");
            InstallGlobalBtn.setText("START");
            InstallKRBtn.setText("START");
            InstallVNGBtn.setText("START");
            InstallTWBtn.setText("START");

        } else {

        }
        findViewById(R.id.settings_menu).setOnClickListener(v -> showSettingsDialog());

    }
    private void setDeviceInfo(TextView textView, String label, String value) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        // Bold black label
        SpannableString labelSpan = new SpannableString(label + ": ");
        labelSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, labelSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        labelSpan.setSpan(new ForegroundColorSpan(Color.BLACK), 0, labelSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.append(labelSpan);

        // Grey value
        SpannableString valueSpan = new SpannableString(value);
        valueSpan.setSpan(new ForegroundColorSpan(Color.GRAY), 0, value.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.append(valueSpan);

        textView.setText(builder);
    }

    private void showSettingsDialog() {
        Dialog dialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.layout_settings);
        dialog.setCancelable(true);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawableResource(android.R.color.transparent);

            // Apply status bar and navigation bar styling to the DIALOG window
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(getResources().getColor(R.color.white));
                window.setNavigationBarColor(getResources().getColor(R.color.white));
                int flags = window.getDecorView().getSystemUiVisibility();
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                window.getDecorView().setSystemUiVisibility(flags);
            }
        }

        // Setup back arrow button
        MaterialToolbar toolbar = dialog.findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(v -> dialog.dismiss());
        }

        setDeviceInfo(dialog.findViewById(R.id.modelText), "Model", Build.MODEL);
        setDeviceInfo(dialog.findViewById(R.id.manufacturerText), "Manufacturer", Build.MANUFACTURER);
        setDeviceInfo(dialog.findViewById(R.id.brandText), "Brand", Build.BRAND);
        setDeviceInfo(dialog.findViewById(R.id.versionText), "Android Version", Build.VERSION.RELEASE);
        setDeviceInfo(dialog.findViewById(R.id.kernelText), "Kernel", System.getProperty("os.version"));

        // Initialize buttons from dialog's view
        MaterialButton InstallTwitterBtn = dialog.findViewById(R.id.InstallTwitter);
String packageNameTwitter = "com.twitter.android";

ApkEnv env = ApkEnv.getInstance();

// === Initial Button Text ===
if (env.isInstalled(packageNameTwitter)) {
    InstallTwitterBtn.setText("LAUNCH");
} else {
    InstallTwitterBtn.setText("INSTALL");
}

// === Click Listener ===
InstallTwitterBtn.setOnClickListener(v -> {
//bitversi = 64;
    if (env.isInstalled(packageNameTwitter)) {
        boolean launched = env.launchApk(packageNameTwitter);
        if (launched) {
            InstallTwitterBtn.setText("STOP");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                InstallTwitterBtn.setText("LAUNCH");
            }, 4000);
        } else {
            Toast.makeText(v.getContext(), "Failed to launch Twitter.", Toast.LENGTH_SHORT).show();
        }
    } else {
        InstallTwitterBtn.setText("INSTALLING...");
        boolean installed = env.installApk(packageNameTwitter);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            InstallTwitterBtn.setText(installed ? "LAUNCH" : "INSTALL");
            Toast.makeText(v.getContext(), installed ? "Twitter installed." : "Install failed.", Toast.LENGTH_SHORT).show();
        }, 2000);
    }
});

// === Long Click (Uninstall) ===
InstallTwitterBtn.setOnLongClickListener(v -> {
    if (env.isInstalled(packageNameTwitter)) {
        env.unInstallApk(packageNameTwitter);
        InstallTwitterBtn.setText("INSTALL");
        Toast.makeText(v.getContext(), "Twitter uninstalled.", Toast.LENGTH_SHORT).show();
        return true;
    } else {
        Toast.makeText(v.getContext(), "Twitter is not installed.", Toast.LENGTH_SHORT).show();
        return false;
    }
});

        
        
        
        
        SharedPreferences sharedPreferences = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (sharedPreferences.contains("hiderecord")) {
            try {
                sharedPreferences.getBoolean("hiderecord", false);
            } catch (ClassCastException e) {
                try {
                    int oldValue = sharedPreferences.getInt("hiderecord", 0);
                    editor.remove("hiderecord");
                    editor.putBoolean("hiderecord", oldValue == 1);
                    editor.apply();
                } catch (ClassCastException e2) {
                    editor.remove("hiderecord");
                    editor.putBoolean("hiderecord", false);
                    editor.apply();
                }
            }
        }
        boolean isHideRecordEnabled = sharedPreferences.getBoolean("hiderecord", false);
        SwitchCompat hideRecordSwitch = dialog.findViewById(R.id.hiderecord);
        hideRecordSwitch.setChecked(isHideRecordEnabled);
        hideRecordSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            editor.putBoolean("hiderecord", isChecked).apply();
        });

        dialog.show();
    }

   @SuppressLint("ResourceAsColor")
void initMenu2() {
    // ================== Buttons ==================
    MaterialButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
    MaterialButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
    MaterialButton InstallKRBtn = findViewById(R.id.InstallKR);
    MaterialButton InstallVNGBtn = findViewById(R.id.InstallVNG);
    MaterialButton InstallTWBtn = findViewById(R.id.InstallTW);

    // ================== Package Names ==================
    String packageNameBG = "com.pubg.imobile";
    String packageNameGl = "com.tencent.ig";
    String packageNameKr = "com.pubg.krmobile";
    String packageNameVng = "com.vng.pubgmobile";
    String packageNameTw = "com.rekoo.pubgm";

    // ================== ApkEnv Instance ==================
    ApkEnv env = ApkEnv.getInstance();

    // ================== Helper Methods ==================


    // ================== Click Listener ==================
    View.OnClickListener makeClickListener = v -> {
        MaterialButton btn = (MaterialButton) v;
        String pkg = (String) v.getTag();

        if (env.isInstalled(pkg)) {
            // ✅ Installed → check OBB + launch
            checkAndCopyObb(pkg, MainActivity.this);

            boolean launched = env.launchApk(pkg);
            Toast.makeText(MainActivity.this,
                    launched ? "Launching " + pkg : "Launch failed for " + pkg,
                    Toast.LENGTH_SHORT).show();

        } else {
            // 🚀 Not installed → install then check OBB
            btn.setText("Installing...");
            boolean installed = env.installApk(pkg);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                btn.setText(installed ? "LAUNCH" : "INSTALL");

                if (installed) {
                    Toast.makeText(MainActivity.this, "Installed " + pkg, Toast.LENGTH_SHORT).show();
                    checkAndCopyObb(pkg, MainActivity.this);
                }
            }, 2500);
        }
    };

    // ================== Long Click Listener (Uninstall) ==================
    View.OnLongClickListener makeLongClickListener = v -> {
        MaterialButton btn = (MaterialButton) v;
        String pkg = (String) v.getTag();

        if (env.isInstalled(pkg)) {
            env.unInstallApk(pkg);
            btn.setText("INSTALL");
            Toast.makeText(MainActivity.this, "Uninstalled " + pkg, Toast.LENGTH_SHORT).show();
            return true;
        } else {
            Toast.makeText(MainActivity.this, "App not installed.", Toast.LENGTH_SHORT).show();
            return false;
        }
    };

    // ================== Assign Tags & Listeners ==================
    InstallBgmiBtn.setTag(packageNameBG);
    InstallGlobalBtn.setTag(packageNameGl);
    InstallKRBtn.setTag(packageNameKr);
    InstallVNGBtn.setTag(packageNameVng);
    InstallTWBtn.setTag(packageNameTw);

    InstallBgmiBtn.setOnClickListener(makeClickListener);
    InstallGlobalBtn.setOnClickListener(makeClickListener);
    InstallKRBtn.setOnClickListener(makeClickListener);
    InstallVNGBtn.setOnClickListener(makeClickListener);
    InstallTWBtn.setOnClickListener(makeClickListener);

    InstallBgmiBtn.setOnLongClickListener(makeLongClickListener);
    InstallGlobalBtn.setOnLongClickListener(makeLongClickListener);
    InstallKRBtn.setOnLongClickListener(makeLongClickListener);
    InstallVNGBtn.setOnLongClickListener(makeLongClickListener);
    InstallTWBtn.setOnLongClickListener(makeLongClickListener);
}
    // Check and copy OBB safely
    void checkAndCopyObb(String pkg, Context ctx) {
        try {
            File bbObbFolder = new File(Environment.getExternalStorageDirectory(), "Android/obb/" + pkg);
            if (!bbObbFolder.exists()) bbObbFolder.mkdirs();

            File[] bbObbFiles = bbObbFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + pkg + "\\.obb"));

            if (bbObbFiles != null && bbObbFiles.length > 0) {
                Toast.makeText(ctx, "OBB already installed ✅", Toast.LENGTH_SHORT).show();
                return;
            }

            File srcFolder = new File(Environment.getExternalStorageDirectory(), "Android/obb/" + pkg);
            File[] srcFiles = srcFolder.listFiles((dir, name) -> name.matches("main\\.\\d+\\." + pkg + "\\.obb"));

            if (srcFiles != null && srcFiles.length > 0) {
                new MyCopyTask(ctx).execute(srcFiles[0].getAbsolutePath(), pkg);
            } else {
                Toast.makeText(ctx, "No OBB found for " + pkg, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(ctx, "OBB check failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
// ================== AsyncTask to copy OBB safely ==================
private class MyCopyTask extends AsyncTask<String, Integer, Boolean> {
    private Context ctx;
    private AlertDialog dialog;
    private ProgressBar progressBar;
    private String message = "";

    public MyCopyTask(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {
        // Build dialog with progress bar
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setCancelable(false);
        View customLayout = LayoutInflater.from(ctx).inflate(R.layout.dialog_new_progress, null);
        progressBar = customLayout.findViewById(R.id.progressBar); // make sure your layout has this
        builder.setView(customLayout);
        dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.show();
    }

    @Override
    protected Boolean doInBackground(String... params) {
        String sourcePath = params[0];
        String pkg = params[1];

        File source = new File(sourcePath);
        File destFolder = new File(Environment.getExternalStorageDirectory(), "Android/obb/" + pkg);
        if (!destFolder.exists()) destFolder.mkdirs();

        File dest = new File(destFolder, source.getName());

        try (InputStream in = new FileInputStream(source);
             OutputStream out = new FileOutputStream(dest)) {

            long total = source.length();
            long copied = 0;
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                copied += read;
                publishProgress((int) ((copied * 100) / total)); // update progress
            }
            out.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            message = e.getMessage();
            return false;
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if (progressBar != null) {
            progressBar.setProgress(values[0]);
        }
    }

    @Override
    protected void onPostExecute(Boolean success) {
        if (dialog != null && dialog.isShowing()) dialog.dismiss();

        if (success) {
            Toast.makeText(ctx, "OBB copied successfully ✅", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(ctx, "Copy failed: " + message, Toast.LENGTH_LONG).show();
        }
    }
}


boolean isPackageInstalled(String packageName) {
        return blackboxCore.isInstalled(packageName, 0);
    }

                

    

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
        stopService(new Intent(MainActivity.get(), FightMode.class));
    }

    private Dialog progressDialog;
    private LottieAnimationView progressBar;

    private LinearProgressIndicator initProgressDialog() {
        progressDialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar);
        progressDialog.setContentView(R.layout.dialog_progress);
        progressDialog.setCancelable(false);

        progressBar = progressDialog.findViewById(R.id.progressBar);

        Window window = progressDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setDimAmount(0f);
        }
        
        return progres;
    }


    public void updateProgress(int progress) {
        // No need to update progress for Lottie animation
    }

    public void doHideProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }







    private void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(MainActivity.get())) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startFloater();
            }
        }
    }

    private void startFloater() {


            //loadAssets("socu64");
            loadAssets("sock64");
            startService(new Intent(MainActivity.get(), FloatService.class));
            startService(new Intent(MainActivity.get(), FightMode.class));

    }

    private void stopPatcher() {
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
        stopService(new Intent(MainActivity.get(), FightMode.class));
       }


void Makedir() {
       
            File GlobalFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.tencent.ig/");
            File KoreaFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.pubg.krmobile/");
            File VietnamFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.vng.pubgmobile/");
            File TaiwanFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.rekoo.pubgm/");
            File BgmiFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.pubg.imobile/");
            GlobalFolder.mkdirs();
            KoreaFolder.mkdirs();
            VietnamFolder.mkdirs();
            TaiwanFolder.mkdirs();
            BgmiFolder.mkdirs();
        }
    
        public void launchbypass() {

    }
    
      void runant(final String nf){
        //excpp("/"+nf);
		}

    
     public void loadAssets(String sockver) {
        daemonPath = MainActivity.this.getFilesDir().toString() + "/" + sockver;
        if (Internal.isRootGiven()) {
            socket = "su -c " + daemonPath;
        } else {
            socket = daemonPath;
        }
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath);
        } catch (IOException e) {
        }
    }
    
        
public void launchbypassNoRoot() {
    Handler handler = new Handler(Looper.getMainLooper());

    // After 20 sec
    handler.postDelayed(() -> {
        runant("/Bypass");
        runant("/NINJA0");
        runant("/AFAQ 786");
        runant("/libpubgm.so");

        // After another 30 sec
        handler.postDelayed(() -> {
            runant("/Bypass");
            runant("/NINJA0");
            runant("/AFAQ 786");
            runant("/libpubgm.so");

            // After another 38 sec
            handler.postDelayed(() -> {
                runant("/Bypass");
                runant("/NINJA0");
                runant("/AFAQ 786");
                runant("/libpubgm.so");
            }, 38_000);

        }, 30_000);

    }, 20_000);
}

    private void Loadssets() {
        //MoveAssets(getFilesDir() + "/", "socs64");
        MoveAssets(getFilesDir() + "/", "sock64");
        MoveAssets(getFilesDir() + "/", "libpubgm.so");
        MoveAssets(getFilesDir() + "/", "NINJA0");
        MoveAssets(getFilesDir() + "/", "libbgmi.so");
        MoveAssets(getFilesDir() + "/", "AFAQ");
        MoveAssets(getFilesDir() + "/", "libpubgm");
        MoveAssets(getFilesDir() + "/", "pubgm.so");
        MoveAssets(getFilesDir() + "/", "via.apk");
        MoveAssets(getFilesDir() + "/", "kernels64");
        MoveAssets(getFilesDir() + "/", "libbgmi");
        MoveAssets(getFilesDir() + "/", "bgmi.so");
        MoveAssets(getFilesDir() + "/", "bgmi");
    }
    
    private boolean MoveAssets(String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        startAutoSlider();
        boolean needsRecreate = getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getBoolean("needs_recreate", false);
        if (needsRecreate) {
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("needs_recreate", false)
                    .apply();
        }
    }




    private LinearProgressIndicator getProgresBar() {
        return progres;
    }

}
