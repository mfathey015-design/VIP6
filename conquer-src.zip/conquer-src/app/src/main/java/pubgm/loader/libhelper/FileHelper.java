package pubgm.loader.libhelper;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import android.os.Environment;
import pubgm.loader.BoxApplication;
import pubgm.loader.R;
import pubgm.loader.activity.MainActivity;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;
import com.blankj.molihuan.utilcode.util.FileUtils;
import com.google.android.material.progressindicator.LinearProgressIndicator;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class FileHelper {

    public static void tryInstallWithCopyObb(MainActivity activity, LinearProgressIndicator prog, String packageName) {
    new Thread(() -> {
        PackageInfo info = null;
        try {
            info = activity.getPackageManager().getPackageInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException err) {
            FLog.error(err.getMessage());
        }

        if (info == null) {
            handleInstallationError(activity, prog, "الرجاء تثبيت اللعبة أولا.");
            return;
        }

        if (!info.applicationInfo.nativeLibraryDir.contains("64")) {
            handleInstallationError(activity, prog, "الرجاء تثبيت إصدار اللعبة 64 بت.");
            return;
        }

        String gameObb = "main." + info.versionCode + "." + info.packageName + ".obb";

        // Candidate source paths (check blackbox and standard Android/obb, and absolute fallbacks)
        File ext = Environment.getExternalStorageDirectory();
        File[] candidates = new File[] {
                new File(ext, "blackbox/Android/obb/" + packageName + "/" + gameObb),
                new File(ext, "Android/obb/" + packageName + "/" + gameObb),
                new File("/storage/emulated/0/blackbox/Android/obb/" + packageName + "/" + gameObb),
                new File("/storage/emulated/0/Android/obb/" + packageName + "/" + gameObb)
        };

        File obbSrc = null;
        for (File c : candidates) {
            FLog.info("Checking OBB candidate: " + c.getAbsolutePath());
            if (c.exists()) {
                obbSrc = c;
                break;
            }
        }

        if (obbSrc == null) {
            handleInstallationError(activity, prog, "فشل في اضافة ملف (OBB) — لم يتم العثور على ملف OBB في المسارات المتوقعة.");
            return;
        }

        // Destination = container path (ApkEnv provides this; you already set it to blackbox/...).
        File virObbDir = ApkEnv.getInstance().getObbContainerPath(packageName);
        if (!virObbDir.exists() && !virObbDir.mkdirs()) {
            handleInstallationError(activity, prog, "فشل في انشاء مجلد OBB الوجهة.");
            return;
        }

        File virObbDest = new File(virObbDir, gameObb);

        activity.runOnUiThread(() -> {
            activity.doHideProgress();
         //   activity.doShowProgress(true);
            if (prog != null) prog.setIndeterminate(true);
        });

        // Copy with progress
        try {
            long totalSize = obbSrc.length();
            if (totalSize <= 0) {
                // fallback: use FileUtils.copy if size unknown
                FileUtils.copy(obbSrc.getAbsolutePath(), virObbDest.getAbsolutePath());
            } else {
                byte[] buffer = new byte[64 * 1024]; // 64KB buffer
                int len;
                long copied = 0;
                try (FileInputStream fis = new FileInputStream(obbSrc);
                     FileOutputStream fos = new FileOutputStream(virObbDest)) {
                    while ((len = fis.read(buffer)) != -1) {
                        fos.write(buffer, 0, len);
                        copied += len;
                        final int progress = (int) ((copied * 100) / totalSize);
                        activity.runOnUiThread(() -> {
                            if (prog != null) {
                                prog.setIndeterminate(false);
                                try {
                                    prog.setProgressCompat(progress, true);
                                } catch (Throwable e) {
                                    try { prog.setProgress(progress); } catch (Throwable ignored) {}
                                }
                            }
                        });
                    }
                    fos.flush();
                }
            }

            FLog.info("OBB copied from: " + obbSrc.getAbsolutePath() + " -> " + virObbDest.getAbsolutePath());

        } catch (Exception err) {
            FLog.error("Copy OBB failed: " + err.getMessage());
            handleInstallationError(activity, prog, "فشل في نسخ OBB: " + err.getMessage());
            return;
        }

        // Install (keep existing behavior). NOTE: installByFile expects an APK PATH (not a package name).
        if (!ApkEnv.getInstance().isInstalled(packageName)) {
            boolean installResult = ApkEnv.getInstance().installByFile(packageName);
            if (!installResult) {
                handleInstallationError(activity, prog, "فشل في الاضافة");
                return;
            }
        }

        ApplicationInfo applicationInfo = ApkEnv.getInstance().getApplicationInfoContainer(packageName);
        if (applicationInfo == null) {
            handleInstallationError(activity, prog, "خطأ، معلومات التطبيق");
            return;
        }

        // --- REMOVED call to MainActivity.get().doInitRecycler(); because it doesn't exist ---
        activity.runOnUiThread(() -> {
            // Update progress to full and hide
            if (prog != null) {
                try { prog.setIndeterminate(false); prog.setProgressCompat(100, true); } catch (Throwable e) { try { prog.setProgress(100); } catch (Throwable ignored) {} }
            }
            activity.doHideProgress();
            ActivityCompat.getActivityCompat().toastImage(R.drawable.ic_check, "اكتمل التثبيت.");
        });

        // Optional: set executable perms on native libs (commented out in original)
        /*File listAbi = new File(applicationInfo.nativeLibraryDir);
        if (listAbi.exists() && listAbi.isDirectory()) {
            for (File abi : listAbi.listFiles()) {
                BoxApplication.get().doChmod(abi.toString(), 755);
            }
        }*/
    }).start();
}


    private static void handleInstallationError(MainActivity activity, LinearProgressIndicator prog, String errorMessage) {
        activity.runOnUiThread(() -> {
            activity.doHideProgress();
            ActivityCompat.getActivityCompat().toastImage(R.drawable.ic_error, errorMessage);
        });
    }
}
