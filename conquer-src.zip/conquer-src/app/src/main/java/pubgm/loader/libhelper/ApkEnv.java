package pubgm.loader.libhelper;


import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import com.blankj.molihuan.utilcode.util.FileUtils;
import net_62v.external.MetaApplicationInstaller;
import net_62v.external.MetaActivityManager;
import net_62v.external.MetaPackageManager;
import net_62v.external.MetaStorageManager;

import pubgm.loader.BoxApplication;
import pubgm.loader.R;
import pubgm.loader.utils.FLog;
import top.niunaijun.blackbox.BlackBoxCore;
import android.widget.Toast;
import java.io.File;
import android.os.Environment;
public class ApkEnv {
    File obbContaine;

    private static ApkEnv singleton;
    private static final int USER_ID = 0; // BlackBox default user

    public static ApkEnv getInstance() {
        if (singleton == null) {
            singleton = new ApkEnv();
        }
        return singleton;
    }

    public ApplicationInfo getApplicationInfo(String packageName) {
        ApplicationInfo applicationInfo = null;
        try {
        	applicationInfo = BoxApplication.get().getPackageManager().getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException err) {
        	FLog.error(err.getMessage());
            BoxApplication.get().showToastWithImage(R.drawable.ic_error, err.getMessage());
            return null;
        }

        /*if (!AbiUtils.isSupport(new File(applicationInfo.sourceDir))) {
            BoxApplication.getInstance().showToastWithImage(R.drawable.ic_error, "Please Install Game " + (FCore.is64Bit() ? "64Bit" : "32Bit") + " version.");
            return null;
        }*/

        return applicationInfo;
    }

    public ApplicationInfo getApplicationInfoContainer(String packageName) {
    	if (!isInstalled(packageName)) {
            BoxApplication.get().showToastWithImage(R.drawable.ic_error, "App not install, install first");
            return null;
        }

        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = MetaPackageManager.getApplicationInfo(packageName);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        if (applicationInfo == null) {
            return null;
        }
        return applicationInfo;
    }

    public boolean isInstalled(String packageName) {
        try {
            return BlackBoxCore.get().isInstalled(packageName, USER_ID);
        } catch (Throwable t) {
            FLog.error("isInstalled failed: " + t.getMessage());
            return false;
        }
    }

    public boolean installApk(String packageName) {
        try {
            BlackBoxCore.get().installPackageAsUser(packageName, USER_ID);
            Toast.makeText(BoxApplication.getInstance(),
                    "Installed: " + packageName,
                    Toast.LENGTH_SHORT).show();
            return true;
        } catch (Throwable t) {
            FLog.error("installApk failed: " + t.getMessage());
            Toast.makeText(BoxApplication.getInstance(),
                    "Install failed: " + packageName,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean unInstallApk(String packageName) {
        try {
            BlackBoxCore.get().uninstallPackageAsUser(packageName, USER_ID);
            Toast.makeText(BoxApplication.getInstance(),
                    "Uninstalled: " + packageName,
                    Toast.LENGTH_SHORT).show();
            return true;
        } catch (Throwable t) {
            FLog.error("unInstallApk failed: " + t.getMessage());
            Toast.makeText(BoxApplication.getInstance(),
                    "Uninstall failed: " + packageName,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean launchApk(String packageName) {
        if (!isInstalled(packageName)) {
            Toast.makeText(BoxApplication.getInstance(),
                    "Client not installed",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        try {
            BlackBoxCore.get().launchApk(packageName, USER_ID);
            return true;
        } catch (Throwable t) {
            FLog.error("launchApk failed: " + t.getMessage());
            Toast.makeText(BoxApplication.getInstance(),
                    "Launch failed: " + packageName,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    // ===== Compatibility Shims =====
    public boolean installByFile(String packageName) {
        return installApk(packageName);
    }

    public boolean installByPackage(String packageName) {
        return installApk(packageName);
    }

    public void unInstallApp(String packageName) {
        unInstallApk(packageName);
    }

    public boolean isRunning(String packageName) {
        // BlackBoxCore doesn’t expose this → stub
        return false;
    }

    public void stopRunningApp(String packageName) {
        // Not supported → just log
        FLog.error("stopRunningApp not supported with BlackBoxCore");
    }

    public boolean tryAddLoader(String packageName) {
        // Loader injection removed → always false
        return false;
    }
    
public File getObbContainerPath(String packageName) {
    // Root of external storage: /storage/emulated/0
    File root = Environment.getExternalStorageDirectory();

    // Custom obb directory under blackbox
    File obbDir = new File(root, "blackbox/Android/obb/" + packageName);

    // Ensure the directory exists
    if (!obbDir.exists()) {
        obbDir.mkdirs();
    }

    return obbDir;
}

    
}
