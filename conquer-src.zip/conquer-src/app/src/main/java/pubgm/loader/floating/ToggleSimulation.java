package pubgm.loader.floating;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.IBinder;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import pubgm.loader.R;
import pubgm.loader.utils.FLog;
import pubgm.loader.utils.FPrefs;


public class ToggleSimulation extends Service {

    private boolean checkStatus;
    private View mainView;
    private RelativeLayout miniFloatView;
    private WindowManager windowManager;
    private LayoutParams paramsView;
    private int screenWidth;
    private int screenHeight;

    public native void ToggleSimulation(boolean value);

    static {
        try {
            System.loadLibrary("JungliCheatz");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        FLog.debug("ToggleSimulation service started");
        // Get screen dimensions
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x;
        screenHeight = size.y;
        
        // Initialize position to center of screen
        paramsView = getParaams();
        paramsView.x = screenWidth / 2;
        paramsView.y = screenHeight / 2;
        
        ShowMainView();
    }

    private void ShowMainView() {
        mainView = LayoutInflater.from(this).inflate(R.layout.toggle_touch, null);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(mainView, paramsView);
        InitShowMainView();
    }

    public FPrefs getPref() {
        return FPrefs.with(this);
    }

    private LayoutParams getParaams() {
        final LayoutParams params = new LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT, 
            getLayoutType(), 
            LayoutParams.FLAG_NOT_FOCUSABLE, 
            PixelFormat.TRANSLUCENT);

        boolean isHideRecordEnabled = getSharedPreferences("espValue", MODE_PRIVATE)
                .getBoolean("hiderecord", false);

        if (isHideRecordEnabled) {
            HideRecorder.setFakeRecorderWindowLayoutParams(params);
        }
        
        // Initialize to center of screen
        params.gravity = Gravity.TOP | Gravity.LEFT; // Changed from CENTER to allow exact positioning
        params.x = screenWidth / 2;
        params.y = screenHeight / 2;
        
        return params;
    }

    private static int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }

    private void InitShowMainView() {
        miniFloatView = mainView.findViewById(R.id.miniFloatMenu);
        RelativeLayout layoutView = mainView.findViewById(R.id.layout_icon_control_aim);
        final ImageView myImageView = mainView.findViewById(R.id.imageview_aim);

        layoutView.setOnTouchListener(new View.OnTouchListener() {
                private int initialX;
                private int initialY;
                private float initialTouchX;
                private float initialTouchY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = paramsView.x;
                            initialY = paramsView.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;

                        case MotionEvent.ACTION_UP:
                            int Xdiff = (int) (event.getRawX() - initialTouchX);
                            int Ydiff = (int) (event.getRawY() - initialTouchY);
                            if (Xdiff < 5 && Ydiff < 5) {
                                if (miniFloatView.getVisibility() == View.VISIBLE) {
                                    if (!checkStatus) {
                                        checkStatus = true;
                                        FLog.debug("ToggleSimulation enabled - X:" + paramsView.x + " Y:" + paramsView.y + " Screen:" + screenWidth + "x" + screenHeight);
                                        ToggleSimulation(true);
                                        myImageView.animate().rotationBy(0).rotation(-45);
                                        myImageView.setImageResource(R.drawable.imo2);
                                    } else {
                                        checkStatus = false;
                                        FLog.debug("ToggleSimulation disabled");
                                        ToggleSimulation(false);
                                        myImageView.animate().rotationBy(-45).rotation(0);
                                        myImageView.setImageResource(R.drawable.imo);
                                    }
                                }
                            }
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            paramsView.x = initialX + (int) (event.getRawX() - initialTouchX);
                            paramsView.y = initialY + (int) (event.getRawY() - initialTouchY);
                            
                            // Keep within screen bounds
                            paramsView.x = Math.max(0, Math.min(paramsView.x, screenWidth));
                            paramsView.y = Math.max(0, Math.min(paramsView.y, screenHeight));
                            
                            if (checkStatus) {
                                FLog.debug("Touch position updated - X:" + paramsView.x + " Y:" + paramsView.y);
                            }
                            windowManager.updateViewLayout(mainView, paramsView);
                            return true;
                    }
                    return false;
                }
            });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        FLog.debug("ToggleSimulation service destroyed");
        checkStatus = false;
        ToggleSimulation(false);
        if (mainView != null)
            windowManager.removeView(mainView);
    }

}
