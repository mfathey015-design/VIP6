package pubgm.loader.floating;

import static pubgm.loader.activity.MainActivity.gameint;
import static pubgm.loader.activity.MainActivity.pushmode;
import static pubgm.loader.utils.ActivityCompat.toastImage;


import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.Nullable;
import pubgm.loader.R;
import pubgm.loader.activity.MainActivity;
import pubgm.loader.utils.FLog;
import com.topjohnwu.superuser.Shell;


import java.util.Locale;
import java.util.function.Consumer;

import org.lsposed.lsparanoid.Obfuscate;
import pubgm.loader.utils.FPrefs;


@Obfuscate
public class FloatService extends Service {

    static {
        try {
            System.loadLibrary("JungliCheatz");
        } catch (UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    Context ctx;
    private View mainView;
    private PowerManager.WakeLock mWakeLock;
    private WindowManager windowManagerMainView;
    private WindowManager.LayoutParams paramsMainView;
    private LinearLayout layout_main_view;
    private RelativeLayout layout_icon_control_view;
    public static String typelogin;

    private void setLokasi(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bahasa", lang);
        editor.apply();

    }

    private void loadbahasa() {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String bahasa = sharedPreferences.getString("bahasa", "");
        setLokasi(bahasa);
    }

    private static int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }

    private void StartAimTouch() {
        startService(new Intent(getApplicationContext(), ToggleSimulation.class));
    }

    private void StopAimTouch() {
        stopService(new Intent(getApplicationContext(), ToggleSimulation.class));
    }

    private void StartAimFloat() {
        startService(new Intent(getApplicationContext(), ToggleAim.class));
    }

    private void StopAimFloat() {
        stopService(new Intent(getApplicationContext(), ToggleAim.class));
    }

    private void StartAimBulletFloat() {
        startService(new Intent(getApplicationContext(), ToggleBullet.class));
    }

    private void StopAimBulletFloat() {
        stopService(new Intent(getApplicationContext(), ToggleBullet.class));
    }

    public native void SettingValue(int setting_code, boolean value);

    public native void SettingMemory(int setting_code, boolean value);

    public native void SettingAim(int setting_code, boolean value);


    public native void RadarSize(int size);

    public native void Range(int range);

    public native void recoil(int recoil);

    public native void recoil2(int recoil);

    public native void recoil3(int recoil);

    public native void Target(int target);

    public native void AimBy(int aimby);

    public native void AimWhen(int aimwhen);

    public native void distances(int distances);

    public native void Bulletspeed(int bulletspeed);

    public native void WideView(int wideview);

    public native void AimingSpeed(int aimingspeed);

    public native void Smoothness(int smoothness);

    public native void TouchSize(int touchsize);

    public native void TouchPosX(int touchposx);

    public native void TouchPosY(int touchposy);


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        ctx = getApplicationContext();
        InitShowMainView();
        loadbahasa();
    }

    private void InitShowMainView() {

        Context themedContext = new ContextThemeWrapper(this, R.style.AppTheme);
        LayoutInflater themedInflater = LayoutInflater.from(themedContext);

        mainView = themedInflater.inflate(R.layout.float_service, null);
        paramsMainView = getparams();
        windowManagerMainView = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManagerMainView.addView(mainView, paramsMainView);
        layout_icon_control_view = mainView.findViewById(R.id.layout_icon_control_view);
        layout_main_view = mainView.findViewById(R.id.layout_main_view);
        adjustLayoutWidth();
        ImageView layout_close_main_view = mainView.findViewById(R.id.close_btn);
        layout_close_main_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                layout_main_view.setVisibility(View.GONE);
                layout_icon_control_view.setVisibility(View.VISIBLE);
            }
        });

        LinearLayout layout_view = mainView.findViewById(R.id.layout_view);
        layout_view.setOnTouchListener(onTouchListener());

        // Get references to all tab views
        final LinearLayout tabVisual = mainView.findViewById(R.id.tab_visual);
        final LinearLayout tabItems = mainView.findViewById(R.id.tab_items);
        final LinearLayout tabVehicles = mainView.findViewById(R.id.tab_vehicles);
        final LinearLayout tabAimbot = mainView.findViewById(R.id.tab_aimbot);
        final LinearLayout tabSdk = mainView.findViewById(R.id.tab_sdk);
        ImageView tabVisualImg = mainView.findViewById(R.id.tab_visual_img);
        TextView tabVisualTxt = mainView.findViewById(R.id.tab_visual_txt);
        ImageView tabItemsImg = mainView.findViewById(R.id.tab_items_img);
        TextView tabItemsTxt = mainView.findViewById(R.id.tab_items_txt);
        ImageView tabVehiclesImg = mainView.findViewById(R.id.tab_vehicles_img);
        TextView tabVehiclesTxt = mainView.findViewById(R.id.tab_vehicles_txt);
        ImageView tabAimbotImg = mainView.findViewById(R.id.tab_aimbot_img);
        TextView tabAimbotTxt = mainView.findViewById(R.id.tab_aimbot_txt);
        ImageView tabSdkImg = mainView.findViewById(R.id.tab_sdk_img);
        TextView tabSdkTxt = mainView.findViewById(R.id.tab_sdk_txt);
        // Update tab visibility based on pushmode
        updateTabVisibility(tabAimbot, tabSdk);
        // Get references to all content views
        final LinearLayout menuf1 = mainView.findViewById(R.id.menuf1);
        final LinearLayout menuf2 = mainView.findViewById(R.id.menuf2);
        final LinearLayout menuf3 = mainView.findViewById(R.id.menuf3);
        final LinearLayout menuf4 = mainView.findViewById(R.id.menuf4);
        final LinearLayout menuf5 = mainView.findViewById(R.id.menuf5);

        // Helper method to hide all content views
        View.OnClickListener hideAllAndShow = new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                // Hide all content views first
                menuf1.setVisibility(View.GONE);
                menuf2.setVisibility(View.GONE);
                menuf3.setVisibility(View.GONE);
                menuf4.setVisibility(View.GONE);
                menuf5.setVisibility(View.GONE);

                // Reset background for all tabs (if needed)
                tabVisual.setSelected(false);
                tabItems.setSelected(false);
                tabVehicles.setSelected(false);
                tabAimbot.setSelected(false);
                tabSdk.setSelected(false);

                // Reset all tab colors to default
                tabVisualImg.clearColorFilter();
                tabVisualTxt.setTextColor(getResources().getColor(android.R.color.black));
                tabItemsImg.clearColorFilter();
                tabItemsTxt.setTextColor(getResources().getColor(android.R.color.black));
                tabVehiclesImg.clearColorFilter();
                tabVehiclesTxt.setTextColor(getResources().getColor(android.R.color.black));
                tabAimbotImg.clearColorFilter();
                tabAimbotTxt.setTextColor(getResources().getColor(android.R.color.black));
                tabSdkImg.clearColorFilter();
                tabSdkTxt.setTextColor(getResources().getColor(android.R.color.black));

                // Set the clicked tab as selected
                v.setSelected(true);

                // Show the appropriate content based on which tab was clicked
                int id = v.getId();
                if (id == R.id.tab_visual) {
                    menuf1.setVisibility(View.VISIBLE);
                    visual(mainView);
                    tabVisualImg.setColorFilter(getResources().getColor(R.color.blue), PorterDuff.Mode.SRC_IN);
                    tabVisualTxt.setTextColor(getResources().getColor(R.color.blue));
                } else if (id == R.id.tab_items) {
                    menuf2.setVisibility(View.VISIBLE);
                    items(mainView);
                    tabItemsImg.setColorFilter(getResources().getColor(R.color.blue), PorterDuff.Mode.SRC_IN);
                    tabItemsTxt.setTextColor(getResources().getColor(R.color.blue));
                } else if (id == R.id.tab_vehicles) {
                    menuf3.setVisibility(View.VISIBLE);
                    setupVehicleMenu(mainView);
                    tabVehiclesImg.setColorFilter(getResources().getColor(R.color.blue), PorterDuff.Mode.SRC_IN);
                    tabVehiclesTxt.setTextColor(getResources().getColor(R.color.blue));
                } else if (id == R.id.tab_aimbot) {
                    menuf4.setVisibility(View.VISIBLE);
                    aimbot(mainView);
                    tabAimbotImg.setColorFilter(getResources().getColor(R.color.blue), PorterDuff.Mode.SRC_IN);
                    tabAimbotTxt.setTextColor(getResources().getColor(R.color.blue));
                } else if (id == R.id.tab_sdk) {
                    menuf5.setVisibility(View.VISIBLE);
                    memory(mainView);
                    tabSdkImg.setColorFilter(getResources().getColor(R.color.blue), PorterDuff.Mode.SRC_IN);
                    tabSdkTxt.setTextColor(getResources().getColor(R.color.blue));
                }
            }
        };

        // Set click listeners for each tab
        tabVisual.setOnClickListener(hideAllAndShow);
        tabItems.setOnClickListener(hideAllAndShow);
        tabVehicles.setOnClickListener(hideAllAndShow);
        tabAimbot.setOnClickListener(hideAllAndShow);
        tabSdk.setOnClickListener(hideAllAndShow);

        // Set initial tab (Visual) as selected and show its content
        tabVisual.setSelected(true);
        menuf1.setVisibility(View.VISIBLE);
        visual(mainView);
    }

    private void adjustLayoutWidth() {
        // Get window manager service
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();

        // Get screen dimensions
        android.graphics.Point size = new android.graphics.Point();
        display.getSize(size);
        int screenWidth = size.x;

        // Get current orientation
        int orientation = getResources().getConfiguration().orientation;

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) layout_main_view.getLayoutParams();

        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            // In portrait mode, use 90% of screen width
            params.width = (int) (screenWidth * 0.9);
        } else {
            // In landscape mode, use fixed width of 400dp
            float density = getResources().getDisplayMetrics().density;
            params.width = (int) (400 * density); // Convert 400dp to pixels
        }

        // Apply the new layout parameters
        layout_main_view.setLayoutParams(params);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = layout_icon_control_view;
            final View expandedView = layout_main_view;
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = paramsMainView.x;
                        initialY = paramsMainView.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);
                        if (Xdiff < 10 && Ydiff < 10) {
                            if (isViewCollapsed()) {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        paramsMainView.x = initialX + (int) (event.getRawX() - initialTouchX);
                        paramsMainView.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManagerMainView.updateViewLayout(mainView, paramsMainView);
                        return true;

                }
                return false;
            }
        };
    }




    private boolean isViewCollapsed() {
        return mainView == null || layout_icon_control_view.getVisibility() == View.VISIBLE;
    }

    private WindowManager.LayoutParams getparams() {
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getLayoutType(),
                getFlagsType(),
                PixelFormat.TRANSLUCENT);
        boolean isHideRecordEnabled = getSharedPreferences("espValue", MODE_PRIVATE)
                .getBoolean("hiderecord", false);

        if (isHideRecordEnabled) {
            HideRecorder.setFakeRecorderWindowLayoutParams(params);
        }
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 0;

        return params;
    }

    private int getFlagsType() {
        int LAYOUT_FLAG = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        return LAYOUT_FLAG;
    }






    @Override
    public void onDestroy() {
        super.onDestroy();
        new Thread(new Runnable() {
            @Override
            public void run() {

            }
        }).start();
        if (mWakeLock != null) {
            mWakeLock.release();
            mWakeLock = null;
        }

        if (mainView != null) {
            windowManagerMainView.removeView(mainView);
        }
    }

    boolean getConfig(String key) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getBoolean(key, false);
    }

    private int getFps() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("fps", 100);
    }

    private void setFps(int fps) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("fps", fps);
        ed.apply();
    }

    private void setValue(String key, boolean b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(key, b);
        ed.apply();

    }

    private void setradarSize(int radarSize) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("radarSize", radarSize);
        ed.apply();
    }

    private int getradarSize() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("radarSize", 0);
    }

    private int getrangeAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrangeAim", 0);
    }

    private void getrangeAim(int getrangeAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrangeAim", getrangeAim);
        ed.apply();
    }

    private int getDistances() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("Distances", 0);
    }

    private void setDistances(int Distances) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("Distances", Distances);
        ed.apply();
    }

    private int getrecoilAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim", 0);
    }

    private void getrecoilAim(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim", getrecoilAim);
        ed.apply();
    }

    private int getrecoilAim2() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim2", 0);
    }

    private void getrecoilAim2(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim2", getrecoilAim);
        ed.apply();
    }

    private int getrecoilAim3() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getrecoilAim2", 0);
    }

    private void getrecoilAim3(int getrecoilAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getrecoilAim2", getrecoilAim);
        ed.apply();
    }

    private int getbulletspeedAim() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getbulletspeedAim", 0);
    }

    private void getbulletspeedAim(int getbulletspeedAim) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getbulletspeedAim", getbulletspeedAim);
        ed.apply();
    }

    private int getwideview() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("getwideview", 0);
    }

    private void getwideview(int getwideview) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("getwideview", getwideview);
        ed.apply();
    }

    void setTouchSize(int touchsize) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("touchsize", touchsize);
        ed.apply();
    }

    int getTouchSize() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("touchsize", 600);
    }

    void setTouchPosX(int posX) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("posX", posX);
        ed.apply();
    }

    int getTouchPosX() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("posX", 650);
    }

    void setTouchPosY(int posY) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("posY", posY);
        ed.apply();
    }

    int getTouchPosY() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("posY", 1400);
    }

    private boolean getConfigitem(String key, boolean a) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getBoolean(key, a);
    }

    private void setConfigitem(String a, boolean b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(a, b);
        ed.apply();
    }

    private int getEspValue(String a, int b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt(a, b);
    }

    private void setEspValue(String a, int b) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(a, b);
        ed.apply();
    }

    private int getAimSpeed() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("AimingSpeed", 18);
    }

    private void setAimSpeed(int AimingSpeed) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("AimingSpeed", AimingSpeed);
        ed.apply();
    }

    private int getSmoothness() {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        return sp.getInt("smoothness", 20);
    }

    private void setSmoothness(int smoothness) {
        SharedPreferences sp = this.getSharedPreferences("espValue", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt("smoothness", smoothness);
        ed.apply();
    }





    public void setaim(final Switch a, final int b) {
        a.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton p1, boolean isChecked) {
                setValue(String.valueOf(a.getText()), a.isChecked());
                SettingAim(b, a.isChecked());
            }
        });
    }

    public void setupVehicleCheckbox(final CheckBox checkBox) {
        checkBox.setChecked(getConfig((String) checkBox.getText()));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setValue(String.valueOf(checkBox.getText()), checkBox.isChecked());
            }
        });
    }

    public void itemss(final CheckBox checkBox) {
        checkBox.setChecked(getConfig((String) checkBox.getText()));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                setValue(String.valueOf(checkBox.getText()), checkBox.isChecked());
            }
        });
    }

    public void memory(final Switch a, final int b) {
        a.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton p1, boolean isChecked) {
                setValue(String.valueOf(a.getText()), a.isChecked());
                SettingMemory(b, a.isChecked());
            }
        });
    }
    public void vehicless(final TextView textView) {
        // Make TextView clickable
        textView.setClickable(true);
        textView.setFocusable(true);

        // Set initial state from stored config
        String key = String.valueOf(textView.getText());
        boolean isSelected = getConfigitem(key, false);
        textView.setBackgroundResource(isSelected ? R.drawable.float_selected : R.drawable.float_unselect);

        // Set click listener to toggle state and store it
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle state
                String itemKey = String.valueOf(textView.getText());
                boolean newState = !getConfigitem(itemKey, false);
                setConfigitem(itemKey, newState);
                textView.setBackgroundResource(newState ? R.drawable.float_selected : R.drawable.float_unselect);
            }
        });
    }
    void setupSeekBar(final SeekBar seekBar, final TextView textView, final int initialValue, final Runnable onChangeFunction) {
        seekBar.setProgress(initialValue);
        textView.setText(String.valueOf(initialValue));
        onChangeFunction.run();
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setText(String.valueOf(progress));
                onChangeFunction.run();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void DrawESP() {
        if (Shell.rootAccess()) {
            FLog.info("Root granted");
            MainActivity.socket = "su -c " + MainActivity.daemonPath;
            startService(new Intent(this, Overlay.class));
        } else {
            FLog.info("Root not granted");
            MainActivity.socket = MainActivity.daemonPath;
            startService(new Intent(MainActivity.get(), Overlay.class));
        }
    }
    public void Execc(String path) {
        try {
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
            ExecuteElf("su -c " + getFilesDir() + path);
            ExecuteElf("chmod 777 " + getFilesDir() + path);
            ExecuteElf(getFilesDir() + path);
        } catch (Exception e) {
        }
    }
    public void Exec(String path, String toast) {
        try {
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
            ExecuteElf("su -c " + getFilesDir() + path);
            ExecuteElf("chmod 777 " + getFilesDir() + path);
            ExecuteElf(getFilesDir() + path);
            toastImage(R.drawable.ic_check, toast);
        } catch (Exception e) {
        }
    }

    private void ExecuteElf(String shell) {
        try {
            Runtime.getRuntime().exec(shell, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void StopESP() {
        stopService(new Intent(this, Overlay.class));
    }

    private void visual(View visual) {

        final Switch drawesp = visual.findViewById(R.id.isenableesp);
        drawesp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    DrawESP();
                } else {
                    StopESP();
                    StopAimFloat();
                    StopAimBulletFloat();
                    StopAimTouch();
                }
            }
        });


        final Switch logobypass = visual.findViewById(R.id.logobypass);
        logobypass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
              if (isChecked) {
                    if (gameint >= 1 && gameint <= 4) {
                   
                    //   Exec("/NINJA0", getString(R.string.bypass_launch_success));
             Exec("/TIGER", getString(R.string.bypass_launch_success));
             Exec("/FUCK", getString(R.string.bypass_launch_success));
             Exec("/XXX", getString(R.string.bypass_launch_success));
                    } else if (gameint == 5) {
                  Exec("/TIGER", getString(R.string.bypass_launch_success));
             Exec("/XXX", getString(R.string.bypass_launch_success));
           //  Exec("/Bypass", getString(R.string.bypass_launch_success));
          //   Exec("/libpubgm.so", getString(R.string.bypass_launch_success));
                    }
                }
            }
        });
        
            /* if (isChecked) {
                        if (bitversi == 64) {
                            if (gameint == 5) {     // BGMI NONROOT BYPSS
             Exec("/NINJA0", getString(R.string.bypass_launch_success));
             Exec("/AFAQ 786", getString(R.string.bypass_launch_success));
             Exec("/libbgmi.so", getString(R.string.bypass_launch_success));
                            } else {                // GLOBAL NONROOT BYPSS
                             Exec("/NINJA0", getString(R.string.bypass_launch_success));
             Exec("/AFAQ 786", getString(R.string.bypass_launch_success));
             Exec("/libpubgm.so", getString(R.string.bypass_launch_success));

                            }

                            }
                        }
                    }
                }
             });*/
        
        final Switch islandbypass = visual.findViewById(R.id.islandbypass);
        islandbypass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    Exec("/ON 2025", getString(R.string.island_active));
                   // Exec("/NINJA2", getString(R.string.island_active));
                }else {
                    Exec("/OF 2035", getString(R.string.island_deactive));

                }
            }
        });
        // Setup visual items with click listeners
        setupVisualItem(visual, R.id.isline, 2);
        setupVisualItem(visual, R.id.isBox, 3);
        setupVisualItem(visual, R.id.isskeleton, 4);
        setupVisualItem(visual, R.id.isdistance, 5);
        setupVisualItem(visual, R.id.ishealth, 6);
        setupVisualItem(visual, R.id.isName, 7);
        setupVisualItem(visual, R.id.ishead, 8);
        setupVisualItem(visual, R.id.isalert, 9);
        setupVisualItem(visual, R.id.isweapon, 10);
        setupVisualItem(visual, R.id.isthrowables, 11);
        setupVisualItem(visual, R.id.isnobot, 15);
        setupVisualItem(visual, R.id.isweaponicon, 16);
      //  setupVisualItem(visual, R.id.islootitems, 14);
        setupVisualItem(visual, R.id.playerid, 111);
        setupVisualItem(visual, R.id.playernation, 222);
        setupVisualItem(visual, R.id.isteamid, 113);
        //setupPlayerNationItem(visual, R.id.isfightmode);
        // Setup FPS radio buttons
        setupFpsRadioButtons(visual);
    }


    // Declare isSelected as a class-level field
    private boolean isSelected = false; // Default to unselected

    private void setupPlayerNationItem(View parent, int viewId) {
        TextView item = parent.findViewById(viewId);

        // Make view clickable
        item.setClickable(true);
        item.setFocusable(true);

        // Set initial state
        item.setBackgroundResource(isSelected ? R.drawable.float_selected : R.drawable.float_unselect);

        // Set click listener with service start/stop
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textView = (TextView) v;
                isSelected = !isSelected; // Toggle state
                Context context = v.getContext();
                textView.setBackgroundResource(isSelected ? R.drawable.float_selected : R.drawable.float_unselect);
                
                Intent fightModeIntent = new Intent(context, FightMode.class);
                if (isSelected) {
                    // Start service when selected
                    context.startService(fightModeIntent);
                } else {
                    // Stop service when deselected
                    context.stopService(fightModeIntent);
                }
            }
        });
    }
    
    private void setupVisualItem(View parent, int viewId, final int code) {
        TextView item = parent.findViewById(viewId);

        // Make view clickable
        item.setClickable(true);
        item.setFocusable(true);

        // Set initial state
        String key = String.valueOf(item.getText());
        boolean isSelected = getConfig(key);
        item.setBackgroundResource(isSelected ? R.drawable.float_selected : R.drawable.float_unselect);
        SettingValue(code, isSelected);

        // Set click listener
        item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textView = (TextView) v;
                String itemKey = String.valueOf(textView.getText());
                boolean newState = !getConfig(itemKey);
                setValue(itemKey, newState);
                textView.setBackgroundResource(newState ? R.drawable.float_selected : R.drawable.float_unselect);
                SettingValue(code, newState);
            }
        });
    }

    private void setupFpsRadioButtons(View visual) {
        final RadioButton fps3 = visual.findViewById(R.id.fps60);
        final RadioButton fps4 = visual.findViewById(R.id.fps120);
        final RadioButton fps5 = visual.findViewById(R.id.fps130);

        int CheckFps = getFps();
        if (CheckFps == 60) {
            fps3.setChecked(true);
            ESPView.sleepTime = 1000 / 60;
        } else if (CheckFps == 90) {
            fps4.setChecked(true);
            ESPView.sleepTime = 1000 / 90;
        } else if (CheckFps == 120) {
            fps5.setChecked(true);
            ESPView.sleepTime = 1000 / 120;
        } else {
            fps3.setChecked(true);
            ESPView.sleepTime = 1000 / 60;
        }

            setupFpsRadioButton(fps3, fps4, fps5, 60);
            setupFpsRadioButton(fps4, fps3, fps5, 90);
            setupFpsRadioButton(fps5, fps3, fps4, 120);

    }

    private void setupFpsRadioButton(RadioButton button, RadioButton other1, RadioButton other2, final int fps) {

            button.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    other1.setChecked(false);
                    other2.setChecked(false);
                    setFps(fps);
                    ESPView.ChangeFps(fps);
                }
            });

    }



    private void items(View items) {
        LinearLayout menui1 = items.findViewById(R.id.items1);
        LinearLayout menui2 = items.findViewById(R.id.lyvehicle);
        View bottomi1 = items.findViewById(R.id.bottomi1);
        View bottomi2 = items.findViewById(R.id.bottomi2);

        // Setup vertical tab bar clicks
        setupVerticalTabBar(items);

        // Show special items section by default
        LinearLayout specialItems = items.findViewById(R.id.specialitems);
            specialItems.setVisibility(View.VISIBLE);

        // Update the first tab appearance
        ImageView firstTab = items.findViewById(R.id.tab1);
            firstTab.setColorFilter(getResources().getColor(R.color.button));


        // Create a click listener for all item TextViews
        View.OnClickListener toggleListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v instanceof TextView) {
                    TextView textView = (TextView) v;
                    String key = String.valueOf(textView.getText());
                    boolean currentState = getConfigitem(key, false);
                    boolean newState = !currentState;

                    // Update the visual state
                    textView.setBackgroundResource(newState ? R.drawable.float_selected : R.drawable.float_unselect);

                    // Save the new state
                    setConfigitem(key, newState);
                }
            }
        };

        // Helper method to setup a TextView
        Consumer<Integer> setupView = (id) -> {
            TextView view = items.findViewById(id);
                // Set initial state
                String key = String.valueOf(view.getText());
                boolean isSelected = getConfigitem(key, false);
                view.setBackgroundResource(isSelected ? R.drawable.float_selected : R.drawable.float_unselect);

                // Make sure the view is clickable and focusable
                view.setClickable(true);
                view.setFocusable(true);

                // Set click listener
                view.setOnClickListener(toggleListener);

        };

        // Setup special items first
        setupView.accept(R.id.Crate);
        setupView.accept(R.id.Airdrop);
        setupView.accept(R.id.DropPlane);
        setupView.accept(R.id.FlareGun);
        setupView.accept(R.id.lootbox);

        // Setup all other item views
        setupView.accept(R.id.Desert);
        setupView.accept(R.id.m416);
        setupView.accept(R.id.QBZ);
        setupView.accept(R.id.SCARL);
        setupView.accept(R.id.AKM);
        setupView.accept(R.id.M16A4);
        setupView.accept(R.id.AUG);
        setupView.accept(R.id.M249);
        setupView.accept(R.id.Groza);
        setupView.accept(R.id.MK47);
        setupView.accept(R.id.M762);
        setupView.accept(R.id.G36C);
        setupView.accept(R.id.DP28);
        setupView.accept(R.id.MG3);
        setupView.accept(R.id.FAMAS);
        setupView.accept(R.id.HoneyBadger);
        setupView.accept(R.id.AC32);
        setupView.accept(R.id.UMP);
        setupView.accept(R.id.bizon);
        setupView.accept(R.id.MP5K);
        setupView.accept(R.id.TommyGun);
        setupView.accept(R.id.vector);
        setupView.accept(R.id.P90);
        setupView.accept(R.id.UZI);
        setupView.accept(R.id.AWM);
        setupView.accept(R.id.QBU);
        setupView.accept(R.id.Kar98k);
        setupView.accept(R.id.M24);
        setupView.accept(R.id.SLR);
        setupView.accept(R.id.SKS);
        setupView.accept(R.id.MK14);
        setupView.accept(R.id.Mini14);
        setupView.accept(R.id.Mosin);
        setupView.accept(R.id.VSS);
        setupView.accept(R.id.AMR);
        setupView.accept(R.id.Win94);
        setupView.accept(R.id.MK12);
        setupView.accept(R.id.x2);
        setupView.accept(R.id.x3);
        setupView.accept(R.id.x4);
        setupView.accept(R.id.x6);
        setupView.accept(R.id.x8);
        setupView.accept(R.id.canted);
        setupView.accept(R.id.hollow);
        setupView.accept(R.id.reddot);
        setupView.accept(R.id.bag1);
        setupView.accept(R.id.bag2);
        setupView.accept(R.id.bag3);
        setupView.accept(R.id.helmet1);
        setupView.accept(R.id.helmet2);
        setupView.accept(R.id.helmet3);
        setupView.accept(R.id.vest1);
        setupView.accept(R.id.vest2);
        setupView.accept(R.id.vest3);
        setupView.accept(R.id.a9);
        setupView.accept(R.id.a7);
        setupView.accept(R.id.a5);
        setupView.accept(R.id.a300);
        setupView.accept(R.id.a45);
        //setupView.accept(R.id.Arrow);
        setupView.accept(R.id.BMG50);
        setupView.accept(R.id.a12);
        setupView.accept(R.id.DBS);
        setupView.accept(R.id.NS2000);
        setupView.accept(R.id.S686);
        setupView.accept(R.id.sawed);
        setupView.accept(R.id.M1014);
        setupView.accept(R.id.S1897);
        setupView.accept(R.id.S12K);
        setupView.accept(R.id.grenade);
        setupView.accept(R.id.molotov);
        setupView.accept(R.id.stun);
        setupView.accept(R.id.smoke);
        setupView.accept(R.id.painkiller);
        setupView.accept(R.id.medkit);
        setupView.accept(R.id.firstaid);
        setupView.accept(R.id.bandage);
        setupView.accept(R.id.injection);
        setupView.accept(R.id.energydrink);
        setupView.accept(R.id.Pan);
        setupView.accept(R.id.Crowbar);
        setupView.accept(R.id.Sickle);
        setupView.accept(R.id.Machete);
        setupView.accept(R.id.Crossbow);
        setupView.accept(R.id.Explosive);
        setupView.accept(R.id.P92);
        setupView.accept(R.id.R45);
        setupView.accept(R.id.P18C);
        setupView.accept(R.id.P1911);
        setupView.accept(R.id.R1895);
        setupView.accept(R.id.Scorpion);
        setupView.accept(R.id.CheekPad);
        setupView.accept(R.id.Choke);
        setupView.accept(R.id.SuppressorSMG);
        setupView.accept(R.id.CompensatorSMG);
        setupView.accept(R.id.FlashHiderSMG);
        setupView.accept(R.id.FlashHiderAr);
        setupView.accept(R.id.ArCompensator);
        setupView.accept(R.id.TacticalStock);
        setupView.accept(R.id.Duckbill);
        setupView.accept(R.id.FlashHiderSniper);
        setupView.accept(R.id.HalfGrip);
        setupView.accept(R.id.StockMicroUZI);
        setupView.accept(R.id.SuppressorSniper);
        setupView.accept(R.id.SuppressorAr);
        setupView.accept(R.id.ExQdSniper);
        setupView.accept(R.id.QdSMG);
        setupView.accept(R.id.ExSMG);
        setupView.accept(R.id.QdSniper);
        setupView.accept(R.id.ExSniper);
        setupView.accept(R.id.ExAr);
        setupView.accept(R.id.ExQdAr);
        setupView.accept(R.id.QdAr);
        setupView.accept(R.id.ExQdSMG);
        setupView.accept(R.id.QuiverCrossBow);
        setupView.accept(R.id.BulletLoop);
        setupView.accept(R.id.ThumbGrip);
        setupView.accept(R.id.LaserSight);
        setupView.accept(R.id.AngledGrip);
        setupView.accept(R.id.LightGrip);
        setupView.accept(R.id.VerticalGrip);
        setupView.accept(R.id.GasCan);
    }

    private void setupVerticalTabBar(View rootView) {
        LinearLayout verticalTabBar = rootView.findViewById(R.id.verticalTabBar);
        LinearLayout specialItems = rootView.findViewById(R.id.specialitems);
        LinearLayout scope = rootView.findViewById(R.id.scope);
        LinearLayout arWeapons = rootView.findViewById(R.id.arweapons);
        LinearLayout lmgWeapons = rootView.findViewById(R.id.LMGweapons);
        LinearLayout smgWeapons = rootView.findViewById(R.id.SMGweapons);
        LinearLayout srWeapons = rootView.findViewById(R.id.SRweapons);
        LinearLayout shotGuns = rootView.findViewById(R.id.ShotGuns);
        LinearLayout pistols = rootView.findViewById(R.id.Pistols);
        LinearLayout milliWeapons = rootView.findViewById(R.id.Milliweapons);
        LinearLayout throwables = rootView.findViewById(R.id.Throwables);
        LinearLayout ammo = rootView.findViewById(R.id.Ammo);
        LinearLayout helmetBag = rootView.findViewById(R.id.HelmetBag);
        LinearLayout consumables = rootView.findViewById(R.id.consumables);
        LinearLayout attachments = rootView.findViewById(R.id.attachments);
        LinearLayout magazines = rootView.findViewById(R.id.magazines);
        LinearLayout grips = rootView.findViewById(R.id.grips);
        LinearLayout others = rootView.findViewById(R.id.others);

        specialItems.setVisibility(View.GONE);
      scope.setVisibility(View.GONE);
       arWeapons.setVisibility(View.GONE);
        lmgWeapons.setVisibility(View.GONE);
        smgWeapons.setVisibility(View.GONE);
        srWeapons.setVisibility(View.GONE);
        shotGuns.setVisibility(View.GONE);
        pistols.setVisibility(View.GONE);
        milliWeapons.setVisibility(View.GONE);
       throwables.setVisibility(View.GONE);
        ammo.setVisibility(View.GONE);
        helmetBag.setVisibility(View.GONE);
       consumables.setVisibility(View.GONE);
       attachments.setVisibility(View.GONE);
       magazines.setVisibility(View.GONE);
        grips.setVisibility(View.GONE);
       others.setVisibility(View.GONE);
            specialItems.setVisibility(View.VISIBLE);


        // Setup click listeners for tab buttons
        setupTabButton(rootView, R.id.tab1, specialItems);
        setupTabButton(rootView, R.id.tab2, scope);
        setupTabButton(rootView, R.id.tab3, arWeapons);
        setupTabButton(rootView, R.id.tab4, lmgWeapons);
        setupTabButton(rootView, R.id.tab5, smgWeapons);
        setupTabButton(rootView, R.id.tab6, srWeapons);
        setupTabButton(rootView, R.id.tab7, shotGuns);
        setupTabButton(rootView, R.id.tab8, pistols);
        setupTabButton(rootView, R.id.tab9, milliWeapons);
        setupTabButton(rootView, R.id.tab10, throwables);
        setupTabButton(rootView, R.id.tab11, ammo);
        setupTabButton(rootView, R.id.tab12, helmetBag);
        setupTabButton(rootView, R.id.tab13, consumables);
        setupTabButton(rootView, R.id.tab14, attachments);
        setupTabButton(rootView, R.id.tab15, magazines);
        setupTabButton(rootView, R.id.tab16, grips);
        setupTabButton(rootView, R.id.tab17, others);
    }

    private void setupTabButton(View rootView, int tabId, View contentView) {
        ImageView tabButton = rootView.findViewById(tabId);
            tabButton.setClickable(true);
            tabButton.setFocusable(true);
            tabButton.setOnClickListener(v -> {
                hideAllContentViews(rootView);
                contentView.setVisibility(View.VISIBLE);
                updateTabAppearance(rootView, tabId);
            });

    }

    private void hideAllContentViews(View rootView) {
        int[] contentIds = {
            R.id.specialitems, R.id.scope, R.id.arweapons, R.id.LMGweapons,
            R.id.SMGweapons, R.id.SRweapons, R.id.ShotGuns, R.id.Pistols,
            R.id.Milliweapons, R.id.Throwables, R.id.Ammo, R.id.HelmetBag,
            R.id.consumables, R.id.attachments, R.id.magazines, R.id.grips,
            R.id.others
        };

        for (int id : contentIds) {
            View view = rootView.findViewById(id);
                view.setVisibility(View.GONE);

        }
    }

    private void updateTabAppearance(View rootView, int selectedTabId) {
        int[] tabIds = {
            R.id.tab1, R.id.tab2, R.id.tab3, R.id.tab4, R.id.tab5,
            R.id.tab6, R.id.tab7, R.id.tab8, R.id.tab9, R.id.tab10,
            R.id.tab11, R.id.tab12, R.id.tab13, R.id.tab14, R.id.tab15,
            R.id.tab16, R.id.tab17
        };

        for (int id : tabIds) {
            ImageView tab = rootView.findViewById(id);
                if (id == selectedTabId) {
                    tab.setColorFilter(getResources().getColor(R.color.button));
                } else {
                    tab.setColorFilter(getResources().getColor(R.color.gray));
                }

        }
    }

    private void aimbot(View aimbot) {

        // Initialize all views with null checks
        TextView menutextaimtouch = aimbot.findViewById(R.id.texttouch);
        TextView aimpre = aimbot.findViewById(R.id.aimpre);
        LinearLayout aimsec = aimbot.findViewById(R.id.aimsec);
        LinearLayout menurotation = aimbot.findViewById(R.id.rotationmenu);
        LinearLayout aimspeedmenu = aimbot.findViewById(R.id.aimspeedmenu);
        LinearLayout recoilmenu = aimbot.findViewById(R.id.recoilmenu);
        LinearLayout recoilmenus2 = aimbot.findViewById(R.id.recoilmenus2);
        LinearLayout smoothnessmenu = aimbot.findViewById(R.id.smoothnessmenu);
        RadioButton touchsimulation = aimbot.findViewById(R.id.touchsimulation);
        RadioButton bullettrack = aimbot.findViewById(R.id.bullettrack);
        RadioButton aimbottt = aimbot.findViewById(R.id.aimbot);
        LinearLayout touchLocationmenu = aimbot.findViewById(R.id.touchlocationmenu);
        LinearLayout touchsizemenu = aimbot.findViewById(R.id.touchsizemenu);
        LinearLayout posXmenu = aimbot.findViewById(R.id.posXmenu);
        LinearLayout posYmenu = aimbot.findViewById(R.id.posYmenu);
            aimpre.setVisibility(View.GONE);
            aimsec.setVisibility(View.VISIBLE);
            menurotation.setAlpha(1.0f);
            aimspeedmenu.setAlpha(1.0f);
            recoilmenu.setAlpha(1.0f);
            recoilmenus2.setAlpha(1.0f);
            smoothnessmenu.setAlpha(1.0f);
            touchsimulation.setEnabled(true);
            touchsimulation.setAlpha(1.0f);
            bullettrack.setEnabled(true);
            bullettrack.setAlpha(1.0f);
            aimbottt.setVisibility(View.VISIBLE);
            bullettrack.setVisibility(View.VISIBLE);
            aimbottt.setEnabled(true);
            aimbottt.setAlpha(1.0f);
if(Shell.rootAccess()){
    touchsimulation.setVisibility(View.VISIBLE);
}else{
    touchsimulation.setVisibility(View.GONE);
}

        // Setup RadioGroups
        final RadioGroup aimby = mainView.findViewById(R.id.aimby);
        final RadioGroup aimwhen = mainView.findViewById(R.id.aimwhen);
        final RadioGroup aimbotmode = mainView.findViewById(R.id.aimbotmode);
        setupRadioGroup(aimby, (group, value) -> AimBy(value));
        setupRadioGroup(aimwhen, (group, value) -> AimWhen(value));
        setupRadioGroup(aimbotmode, (group, value) -> Target(value));

        // Setup Range SeekBar
        SeekBar rangeSeekBar = aimbot.findViewById(R.id.range);
        TextView rangeText = aimbot.findViewById(R.id.rangetext);
            setupSeekBar(rangeSeekBar, rangeText, getrangeAim(), () -> {
                int range = rangeSeekBar.getProgress();
                Range(range);
                getrangeAim(range);
            });


        // Setup Distance SeekBar
        SeekBar distanceSeekBar = aimbot.findViewById(R.id.distances);
        TextView distanceText = aimbot.findViewById(R.id.distancetext);
            setupSeekBar(distanceSeekBar, distanceText, getDistances(), () -> {
                int distance = distanceSeekBar.getProgress();
                distances(distance);
                setDistances(distance);
            });


        // Setup Bullet Speed SeekBar
        SeekBar bulletSpeedSeekBar = aimbot.findViewById(R.id.bulletspeed);
        TextView bulletSpeedText = aimbot.findViewById(R.id.bulletspeedtext);
            setupSeekBar(bulletSpeedSeekBar, bulletSpeedText, getbulletspeedAim(), () -> {
                int speed = bulletSpeedSeekBar.getProgress();
                Bulletspeed(speed);
                getbulletspeedAim(speed);
            });


        // Setup Recoil SeekBars
        SeekBar recoilSeekBar = aimbot.findViewById(R.id.Recoil);
        TextView recoilText = aimbot.findViewById(R.id.recoiltext);
            setupSeekBar(recoilSeekBar, recoilText, getrecoilAim(), () -> {
                int recoil = recoilSeekBar.getProgress();
                recoil(recoil);
                getrecoilAim(recoil);
            });


        SeekBar recoilSeekBar2 = aimbot.findViewById(R.id.Recoil2);
        TextView recoilText2 = aimbot.findViewById(R.id.recoiltext2);
            setupSeekBar(recoilSeekBar2, recoilText2, getrecoilAim2(), () -> {
                int recoil = recoilSeekBar2.getProgress();
                recoil2(recoil);
                getrecoilAim2(recoil);
            });


        SeekBar recoilSeekBar3 = aimbot.findViewById(R.id.Recoils2);
        TextView recoilText3 = aimbot.findViewById(R.id.recoiltexts2);
            setupSeekBar(recoilSeekBar3, recoilText3, getrecoilAim3(), () -> {
                int recoil = recoilSeekBar3.getProgress();
                recoil3(recoil);
                getrecoilAim3(recoil);
            });
        SeekBar touchSizeSeekBar = aimbot.findViewById(R.id.touchsize);
        TextView touchSizeText = aimbot.findViewById(R.id.touchsizetext);
            setupSeekBar(touchSizeSeekBar, touchSizeText, getTouchSize(), () -> {
                int size = touchSizeSeekBar.getProgress();
                setTouchSize(size);
                TouchSize(size);
            });
        SeekBar touchPosXSeekBar = aimbot.findViewById(R.id.touchPosX);
        TextView touchPosXText = aimbot.findViewById(R.id.touchPosXtext);
            setupSeekBar(touchPosXSeekBar, touchPosXText, getTouchPosX(), () -> {
                int posX = touchPosXSeekBar.getProgress();
                setTouchPosX(posX);
                TouchPosX(posX);
            });


        // Setup touch position Y seekbar
        SeekBar touchPosYSeekBar = aimbot.findViewById(R.id.touchPosY);
        TextView touchPosYText = aimbot.findViewById(R.id.touchPosYtext);
            setupSeekBar(touchPosYSeekBar, touchPosYText, getTouchPosY(), () -> {
                int posY = touchPosYSeekBar.getProgress();
                setTouchPosY(posY);
                TouchPosY(posY);
            });


        // Setup smoothness seekbar
        SeekBar smoothnessSeekBar = aimbot.findViewById(R.id.Smoothness);
        TextView smoothnessText = aimbot.findViewById(R.id.smoothtext);
            setupSeekBar(smoothnessSeekBar, smoothnessText, getSmoothness(), () -> {
                int smoothness = smoothnessSeekBar.getProgress();
                setSmoothness(smoothness);
                Smoothness(smoothness);
            });


        // Setup aiming speed seekbar
        SeekBar aimingSpeedSeekBar = aimbot.findViewById(R.id.aimingspeed);
        TextView aimingSpeedText = aimbot.findViewById(R.id.aimingspeedtext);
            setupSeekBar(aimingSpeedSeekBar, aimingSpeedText, getAimSpeed(), () -> {
                int speed = aimingSpeedSeekBar.getProgress();
                setAimSpeed(speed);
                AimingSpeed(speed);
            });


        // Setup switches
        final Switch aimKnocked = aimbot.findViewById(R.id.aimknocked);

            setaim(aimKnocked, 3);


        final Switch aimignore = aimbot.findViewById(R.id.aimignorebot);
            setaim(aimignore, 4);


        final Switch changerotation = aimbot.findViewById(R.id.rotationscren);

            setaim(changerotation, 5);


        final Switch touchlocation = aimbot.findViewById(R.id.touchlocation);
            setaim(touchlocation, 6);


        // Setup RadioGroup for aim modes
        RadioGroup aimgrup = aimbot.findViewById(R.id.grupaim);
        aimgrup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.disableaim:
                        StopAimBulletFloat();
                        StopAimFloat();
                        StopAimTouch();
                           menutextaimtouch.setVisibility(View.GONE);
                           menurotation.setVisibility(View.GONE);
                           aimspeedmenu.setVisibility(View.GONE);
                            smoothnessmenu.setVisibility(View.GONE);
                        break;

                    case R.id.aimbot:
                        StartAimFloat();
                        StopAimBulletFloat();
                        StopAimTouch();
                            menutextaimtouch.setVisibility(View.GONE);
                           menurotation.setVisibility(View.GONE);
                           aimspeedmenu.setVisibility(View.GONE);
                           smoothnessmenu.setVisibility(View.GONE);
                           touchLocationmenu.setVisibility(View.GONE);
                           touchsizemenu.setVisibility(View.GONE);
                            recoilmenu.setVisibility(View.VISIBLE);
                            posXmenu.setVisibility(View.GONE);
                           posYmenu.setVisibility(View.GONE);
                        break;

                    case R.id.touchsimulation:
                        StartAimTouch();
                        StopAimBulletFloat();
                        StopAimFloat();
                        menutextaimtouch.setVisibility(View.VISIBLE);
                        menurotation.setVisibility(View.VISIBLE);
                        aimspeedmenu.setVisibility(View.VISIBLE);
                        smoothnessmenu.setVisibility(View.VISIBLE);
                        touchLocationmenu.setVisibility(View.VISIBLE);
                        touchsizemenu.setVisibility(View.VISIBLE);
                        recoilmenu.setVisibility(View.VISIBLE);
                        recoilmenus2.setVisibility(View.VISIBLE);
                        posXmenu.setVisibility(View.VISIBLE);
                        posYmenu.setVisibility(View.VISIBLE);
                        break;

                    case R.id.bullettrack:
                        StartAimBulletFloat();
                        StopAimFloat();
                        StopAimTouch();
                            menutextaimtouch.setVisibility(View.GONE);
                           menurotation.setVisibility(View.GONE);
                            aimspeedmenu.setVisibility(View.GONE);
                           smoothnessmenu.setVisibility(View.GONE);
                            touchLocationmenu.setVisibility(View.GONE);
                            touchsizemenu.setVisibility(View.GONE);
                           recoilmenu.setVisibility(View.GONE);
                           recoilmenus2.setVisibility(View.GONE);
                            posXmenu.setVisibility(View.GONE);
                           posYmenu.setVisibility(View.GONE);
                        break;
                }
            }
        });

    }

    // Add vehicle method to handle vehicle-related UI
    private void setupVehicleMenu(View vehicle) {
        View.OnClickListener toggleListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v instanceof TextView) {
                    TextView textView = (TextView) v;
                    String key = String.valueOf(textView.getText());
                    boolean currentState = getConfigitem(key, false);
                    boolean newState = !currentState;
                    textView.setBackgroundResource(newState ? R.drawable.float_selected : R.drawable.float_unselect);
                    setConfigitem(key, newState);
                }
            }
        };

        // Get the vehicle menu view
        LinearLayout vehicleMenu = mainView.findViewById(R.id.menuf3);
        if (vehicleMenu == null) {
            return;
        }

        final TextView UTV = vehicleMenu.findViewById(R.id.UTV);
        if (UTV != null) vehicless(UTV);

        final TextView Buggy = vehicleMenu.findViewById(R.id.Buggy);
        if (Buggy != null) vehicless(Buggy);

        final TextView UAZ = vehicleMenu.findViewById(R.id.UAZ);
        if (UAZ != null) vehicless(UAZ);

        final TextView Trike = vehicleMenu.findViewById(R.id.Trike);
        if (Trike != null) vehicless(Trike);

        final TextView Bike = vehicleMenu.findViewById(R.id.Bike);
        if (Bike != null) vehicless(Bike);

        final TextView Dacia = vehicleMenu.findViewById(R.id.Dacia);
        if (Dacia != null) vehicless(Dacia);

        final TextView Jet = vehicleMenu.findViewById(R.id.Jet);
        if (Jet != null) vehicless(Jet);

        final TextView Boat = vehicleMenu.findViewById(R.id.Boat);
        if (Boat != null) vehicless(Boat);

        final TextView Scooter = vehicleMenu.findViewById(R.id.Scooter);
        if (Scooter != null) vehicless(Scooter);

        final TextView Bus = vehicleMenu.findViewById(R.id.Bus);
        if (Bus != null) vehicless(Bus);

        final TextView Mirado = vehicleMenu.findViewById(R.id.Mirado);
        if (Mirado != null) vehicless(Mirado);

        final TextView Rony = vehicleMenu.findViewById(R.id.Rony);
        if (Rony != null) vehicless(Rony);

        final TextView Snowbike = vehicleMenu.findViewById(R.id.Snowbike);
        if (Snowbike != null) vehicless(Snowbike);

        final TextView Snowmobile = vehicleMenu.findViewById(R.id.Snowmobile);
        if (Snowmobile != null) vehicless(Snowmobile);

        final TextView Tempo = vehicleMenu.findViewById(R.id.Tempo);
        if (Tempo != null) vehicless(Tempo);

        final TextView Truck = vehicleMenu.findViewById(R.id.Truck);
        if (Truck != null) vehicless(Truck);

        final TextView MonsterTruck = vehicleMenu.findViewById(R.id.MonsterTruck);
        if (MonsterTruck != null) vehicless(MonsterTruck);

        final TextView BRDM = vehicleMenu.findViewById(R.id.BRDM);
        if (BRDM != null) vehicless(BRDM);

        final TextView ATV = vehicleMenu.findViewById(R.id.ATV);
        if (ATV != null) vehicless(ATV);

        final TextView LadaNiva = vehicleMenu.findViewById(R.id.LadaNiva);
        if (LadaNiva != null) vehicless(LadaNiva);

        final TextView Motorglider = vehicleMenu.findViewById(R.id.Motorglider);
        if (Motorglider != null) vehicless(Motorglider);

        final TextView CoupeRB = vehicleMenu.findViewById(R.id.CoupeRB);
        if (CoupeRB != null) vehicless(CoupeRB);
    }
    private void memory(View memory) {
        final Switch less = memory.findViewById(R.id.isreducerecoil);
        memory(less, 1);
        final Switch Cross = memory.findViewById(R.id.issmallcross);
        memory(Cross, 2);
        final Switch amms = memory.findViewById(R.id.isaimlock);
        memory(amms, 3);
        final Switch magic = memory.findViewById(R.id.ismagichead);
        memory(magic, 6);
        final SeekBar wideviewSeekBar = memory.findViewById(R.id.rangewide);
        final TextView wideviewText = memory.findViewById(R.id.rangetextwide);
        setupSeekBar(wideviewSeekBar, wideviewText, getwideview(), new Runnable() {
            @Override
            public void run() {
                WideView(wideviewSeekBar.getProgress());
                getwideview(wideviewSeekBar.getProgress());
            }
        });
    }

    private void updateTabVisibility(View aimTab, View sdkTab) {
        int currentPushMode = MainActivity.pushmode;
        if (currentPushMode == 0) {
            aimTab.setVisibility(View.GONE);
            sdkTab.setVisibility(View.GONE);
        } else {
            aimTab.setVisibility(View.VISIBLE);
            sdkTab.setVisibility(View.VISIBLE);
        }
    }

    
    private void setupRadioGroup(RadioGroup radioGroup, RadioGroup.OnCheckedChangeListener listener) {
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId != -1) { // Ensure a valid selection
                RadioButton selectedButton = mainView.findViewById(checkedId);
                if (selectedButton != null && selectedButton.getTag() != null) {
                    int value = Integer.parseInt(selectedButton.getTag().toString());
                    listener.onCheckedChanged(group, value);
                }
            }
        });
    }

}
