package pubgm.loader.utils;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.blankj.molihuan.utilcode.util.ToastUtils;
import com.cazaea.sweetalert.SweetAlertDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import org.jdeferred.android.AndroidDeferredManager;
import org.lsposed.lsparanoid.Obfuscate;
import pubgm.loader.R;

@Obfuscate
public class ActivityCompat extends AppCompatActivity {
    private static ActivityCompat activityCompat;
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    public static int PERMISSION_REQUEST_STORAGE = 100;
    public static int REQUEST_MANAGE_UNKNOWN_APP_SOURCES = 200;
    public boolean isLogin = false;
    public FPrefs prefs;
    public static String name;
    public static int version;
    public static String url;
    public static ActivityCompat getActivityCompat() {
        return activityCompat;
    }

    public FPrefs getPref() {
        return FPrefs.with(this);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        activityCompat = this;
        super.onCreate(savedInstanceState);

        prefs = getPref();

        ManageFiles();
    }
    
    public void toast(CharSequence msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(R.drawable.ic_tumn);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        _toast.show(msg);
    }
    
    public static void toastImage(int id, CharSequence msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(id);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        _toast.show(msg);
    }



    public void takeFilePermissions() {
        new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText(getString(R.string.file_access_title))
                .setContentText(getString(R.string.file_access_message))
                .setConfirmText(getString(R.string.grant_permission))
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            Intent intent = new Intent();
                            intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        } else {
                            androidx.core.app.ActivityCompat.requestPermissions(
                                    ActivityCompat.this,
                                    new String[]{
                                            Manifest.permission.READ_EXTERNAL_STORAGE,
                                            Manifest.permission.MANAGE_EXTERNAL_STORAGE
                                    },
                                    1);
                        }
                    }
                })
                .setCancelText(getString(R.string.exit))
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();
                        finish();
                        System.exit(0);
                    }
                })
                .show();
    }


    public boolean isPermissionGaranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          return Environment.isExternalStorageManager();
        } else {
          return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    public void InstllUnknownApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!getPackageManager().canRequestPackageInstalls()) {
                SweetAlertDialog obj = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
                obj.setTitleText("Permission Required");
                obj.setContentText("Please allow Install Unknown App Source");
                obj.setConfirmText("Yes");
                obj.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();
                        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_MANAGE_UNKNOWN_APP_SOURCES);
                    }
                });
                obj.setCancelable(false);
                obj.show();
            } else {
                if (!isPermissionGaranted()) {
                    takeFilePermissions();
                }
            }
        }
    }


    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                SweetAlertDialog obj = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
                obj.setTitleText("Permission Required");
                obj.setContentText("Please allow permission for floating window");
                obj.setConfirmText("Yes");
                obj.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                    }
                });
                obj.setCancelable(false);
                obj.show();
            } else {
                InstllUnknownApp();
            }
        }
    }

    
    public void ManageFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                androidx.core.app.ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_STORAGE);
            } else {
                OverlayPermision();
            }
        }
    }
    
    protected AndroidDeferredManager defer() {
        return UiKit.defer();
    }
    
    private long backPressedTime = 0; 
    
    @Override
    public void onBackPressed() {
        if (isLogin) {
            long t = System.currentTimeMillis();
            if (t - backPressedTime > 2000) {    // 2 secs
                backPressedTime = t;
                toast("Press back again to exit");
            } else {
                super.onBackPressed();
            }
        }
    }

    
}
