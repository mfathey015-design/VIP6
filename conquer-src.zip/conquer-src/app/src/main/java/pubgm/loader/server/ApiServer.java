package pubgm.loader.server;

import pubgm.loader.utils.FLog;

public class ApiServer {

    static {
        try {
            System.loadLibrary("JungliCheatz");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    public static native String mainURL();
    public static native String getOwner();
    public static native String activity();
    public static native String EXP();

}
