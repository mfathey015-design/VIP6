package pubgm.loader.activity;

import static pubgm.loader.server.ApiServer.mainURL;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import pubgm.loader.Component.DownC;
import pubgm.loader.Component.Prefs;
import pubgm.loader.R;
import pubgm.loader.server.ApiServer;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;

import com.cazaea.sweetalert.SweetAlertDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import org.lsposed.lsparanoid.Obfuscate;
import java.util.Locale;

@Obfuscate
public class LoginActivity extends ActivityCompat {

    static {
        try {
            System.loadLibrary("JungliCheatz");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    public static boolean mahyong = false;

    private static final String QUESTION = "Q: %s";
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    private static final String USER = "USER";
    private static final String PASS = "PASS";
    private static String ModeSelect;
    public static String USERKEY, PASSKEY;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightStatusBar(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.white));
            getWindow().setNavigationBarColor(getResources().getColor(R.color.white));
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
        setContentView(R.layout.activity_login);
        mahyong = true;
        if (!mahyong){
            finish();
            finishActivity(1);
        }
        loadbahasa();
        initDesign();
    }

public void telegramcall(){
    String telegramUrl = ApiServer.getOwner();
    Intent intent = new Intent(Intent.ACTION_VIEW);
    intent.setData(Uri.parse(telegramUrl));
    intent.setPackage("org.telegram.messenger");
    try {
        this.startActivity(intent);
    } catch (ActivityNotFoundException e) {
        Intent fallbackIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl));
        this.startActivity(fallbackIntent);
    }
}


    public void initDesign(){
        prefs = Prefs.with(this);
        final Context m_Context = this;
        TextView copyrightLabel = findViewById(R.id.copyright_label);
        TextInputEditText textUsername = findViewById(R.id.email_field);
        TextInputLayout emailLayout = findViewById(R.id.email_layout);  // Assuming this is where endIconDrawable is used
        MaterialButton btnSignIn = findViewById(R.id.login_button);
        textUsername.setText(prefs.read(USER, ""));
        TextView telegram = findViewById(R.id.sign_up_button);

        copyrightLabel.setText("CONQURER");
        telegram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String telegramUrl = ApiServer.getOwner();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(telegramUrl));
                intent.setPackage("org.telegram.messenger");
                try {
                    v.getContext().startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Intent fallbackIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl));
                    v.getContext().startActivity(fallbackIntent);
                }
            }
        });


        // Initialize language spinner
        Spinner languageSpinner = findViewById(R.id.splang);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.languages, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        // Set initial selection based on saved language
        String savedLanguage = prefs.read("bahasa", "en");
        int position = 0;
        switch (savedLanguage) {
            case "zh":
                position = 0;
                break;
            case "ar":
                position = 1;
                break;
            case "en":
                position = 2;
                break;
        }
        languageSpinner.setSelection(position);

        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedLanguage = "";
                switch (position) {
                    case 0:
                        selectedLanguage = "zh";
                        break;
                    case 1:
                        selectedLanguage = "ar";
                        break;
                    case 2:
                        selectedLanguage = "en";
                        break;
                }
                if (!selectedLanguage.equals(prefs.read("bahasa", "en"))) {
                    prefs.write("bahasa", selectedLanguage);
                    setLokasi(selectedLanguage);
                    recreate();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        btnSignIn.setOnClickListener(
    new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if (!textUsername.getText().toString().isEmpty()) {

                prefs.write(USER, textUsername.getText().toString());

                String userKey = textUsername.getText().toString().trim();
                String combinedKey = userKey;

                Login(LoginActivity.this, combinedKey, ModeSelect);

                USERKEY = userKey;
            }




        }
    });
        emailLayout.setEndIconOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                String ed = clipboardManager.getText().toString();

                if (!ed.isEmpty()) {
                    textUsername.setText(ed);
                } else {
                    Toast.makeText(m_Context, String.format(QUESTION, R.string.please_copy_licence_and_paste), Toast.LENGTH_SHORT).show();
                }
            }
        });




    }


    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    







    private static void Login(final LoginActivity m_Context, final String userKey, final String modeSelect) {
        LayoutInflater inflater = LayoutInflater.from(m_Context);
        View viewloading = inflater.inflate(R.layout.animation_login, null);
        @SuppressLint("ResourceType") AlertDialog dialogloading = new AlertDialog.Builder(m_Context, 5)
                        .setView(viewloading)
                        .setCancelable(false)
                        .create();
        dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogloading.show();

        final Handler loginHandler =
                new Handler() {
                    @SuppressLint("HandlerLeak")
                    @Override
                    public void handleMessage(Message msg) {
                        if (msg.what == 0) {
                            toastImage(R.drawable.ic_check,"Login Success");
              Intent i = new Intent(m_Context.getApplicationContext(), MainActivity.class);
            m_Context.startActivity(i);
                        new DownC(m_Context).execute(mainURL());

                        } else if (msg.what == 1) {
                            SweetAlertDialog obj = new SweetAlertDialog(m_Context, SweetAlertDialog.WARNING_TYPE);
                            obj.setTitleText("Login Failed !");
                            obj.setContentText(msg.obj.toString());
                            obj.setConfirmText("OK");
                            obj.setCancelable(false);
                            obj.show();
                        }
                        dialogloading.dismiss();
                    }
                };

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        String result = native_Check(m_Context, userKey);
                        if (result.equals("OK")) {
                            loginHandler.sendEmptyMessage(0);
                        } else {
                            Message msg = new Message();
                            msg.what = 1;
                            msg.obj = result;
                            loginHandler.sendMessage(msg);
                        }
                    }
                })
                .start();
    }



    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            OverlayPermision();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            InstllUnknownApp();
        } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) {
            if (!isPermissionGaranted()) {
                takeFilePermissions();
            }
        }
    }

    private void setLokasi(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bahasa", lang);
        editor.apply();
    }

    private void loadbahasa() {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String bahasa = sharedPreferences.getString("bahasa", "");
        setLokasi(bahasa);
    }

    private static native String native_Check(Context context, String userKey);

}
