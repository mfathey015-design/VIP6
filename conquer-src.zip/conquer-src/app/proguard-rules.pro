

-keep class pubgm.loader.floating.** { *; }
-keep class  net_62v.external.** { *; }

-optimizations
-keepattributes Signature

-keep class pubgm.loader.floating.FloatService {
    public <methods>;
}

-keep class io.grpc.** {*;}

-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

-dontwarn javax.annotation.Nullable
-dontwarn com.squareup.okhttp.CipherSuite
-dontwarn com.squareup.okhttp.ConnectionSpec
-dontwarn com.squareup.okhttp.TlsVersion
-dontwarn org.slf4j.impl.StaticLoggerBinder
-dontwarn javax.annotation.ParametersAreNonnullByDefault
-dontwarn javax.lang.model.element.Modifier
-dontwarn org.slf4j.impl.StaticMDCBinder
-dontwarn org.slf4j.impl.StaticMarkerBinder

-dontwarn com.hjq.permissions.**
-dontwarn top.niunaijun.android_mirror.**
-dontwarn top.canyie.pine.**
-dontwarn top.canyie.pine.xposed.**
-dontwarn top.canyie.dreamland.**

-keep class com.hjq.permissions.** {
    public <methods>;
}

-keep class top.niunaijun.android_mirror.** {
    public <methods>;
}

-keep class top.canyie.pine.** {
    public <methods>;
}

-keep class top.canyie.pine.xposed.** {
    public <methods>;
}

-keep class top.canyie.dreamland.** {
    public <methods>;
}
-keep class ** {
    public <methods>;
}

-keep class * {
    public <methods>;
}

-keep class com.hjq.permissions.** {*;}
-keep class top.niunaijun.android_mirror.** {*;}
-keep class top.canyie.pine.** {*;}
-keep class top.canyie.pine.xposed.** {*;}
-keep class top.canyie.dreamland.** {*;}

