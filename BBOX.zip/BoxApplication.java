package pubgm.loader;

import android.content.Context;
import android.widget.Toast;
import android.app.Application;
import java.io.IOException;
import android.content.pm.PackageInfo;
import java.io.File;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.AppLifecycleCallback;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

public class BoxApplication extends Application {


    public static BoxApplication gApp;

    public static BoxApplication get() {
        return gApp;
    }

    private final String[] process_names = {
            "com.pubg.krmobile",
            "com.tencent.ig",
            "com.rekoo.pubgm",
            "com.vng.pubgmobile",
            "com.pubg.imobile"
    };

    @Override  
    protected void attachBaseContext(Context base) {  
        super.attachBaseContext(base);  
        try {  
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {  
                @Override  
                public String getHostPackageName() {  
                    return base.getPackageName();  
                }  
            });  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  

    @Override
    public void onCreate() {
        super.onCreate();
        gApp = this;

        try {
            BlackBoxCore.SdkKey("FAHADxKATANA");
            BlackBoxCore.get().doCreate();


            BlackBoxCore.get().addAppLifecycleCallback(new AppLifecycleCallback() {
                @Override
                public void beforeApplicationOnCreate(String packageName, String processName, Application application, int userId) {
                    try {
                        for (String pkg : process_names) {
                            if (packageName.equals(pkg)) { // ✅ FIXED CONDITION

                                // ✅ SAME PATH (IMPORTANT)
                                File lib = new File(getFilesDir(), "libpubgm.so");
                                File lib2 = new File(getFilesDir(), "libbgmi.so");

                                if (lib.exists()) {
                                    try {
                                        // الكود الافتراضي الفاضي بتاعك
                                    } catch (Throwable e) {
                                        
                                    }
                                } else {
                                    
                                }
                            }
                        }
                    } catch (Throwable e) {
                        
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}